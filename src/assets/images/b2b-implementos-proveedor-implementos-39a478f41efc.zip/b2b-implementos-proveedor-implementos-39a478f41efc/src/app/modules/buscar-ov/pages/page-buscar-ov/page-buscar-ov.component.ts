import { Component, OnInit } from '@angular/core';
import { DataOV, InfoOvCliente } from 'src/app/shared/interfaces/info-ov-cliente.model';
import Swal from 'sweetalert2';
import { map } from 'rxjs/operators';
import { CarroService } from 'src/app/shared/services/carroService/carro.service';

@Component({
  selector: 'app-page-buscar-ov',
  templateUrl: './page-buscar-ov.component.html',
  styleUrls: ['./page-buscar-ov.component.scss']
})
export class PageBuscarOvComponent implements OnInit {
  ov:string;
  infoClienteOv:DataOV

  constructor(private carroService:CarroService) { }

  ngOnInit() {
    this.ov="1434753";
    this.buscarOv(this.ov)
  }

  buscarOv(ov:string){
    console.log(ov);
    if(ov == undefined || ov == ''){
      Swal.fire("Error","Debe ingresar al menos un número","warning")
    }else {
      let ovCompleta = "OV-"+ ov
      this.carroService.getCompraOv(ovCompleta).pipe(
          map( (data:InfoOvCliente) => {
            if(data.msg == 'sin registro'){
              Swal.fire("...Oops","No se encuentra OV-"+ov,"error")
              return;
            } else {
              this.infoClienteOv = data.data
              return;}
            }
          )
      ).subscribe()
    }
   
    

  }
}
