import { Component, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { LocalStorageService } from 'angular-2-local-storage';
import { CatalogoService } from 'src/app/shared/services/catalogoService/catalogo.service';

@Component({
  selector: 'app-page-portada',
  templateUrl: './page-portada.component.html',
  styleUrls: ['./page-portada.component.scss']
})
export class PagePortadaComponent implements OnInit {

  formPortada: FormGroup;
  fileData: File = null;
  previewUrl: any = null;
  contraPortada: any = null;
  fileUploadProgress: string = null;
  uploadedFilePath: string = null;
  constructor(private fb: FormBuilder, private localS: LocalStorageService, private catalogoService: CatalogoService) {
    this.formPortada = this.fb.group({
      portadaImg: new FormControl(null, Validators.required),
      contraPortadaImg: new FormControl(null, Validators.required),
      urlPortada: new FormControl(null, Validators.required),
      urlContraPortada: new FormControl(null, Validators.required),
    })

    let objeto: any = localS.get('catalogo');
    this.cargarDatos(objeto);
  }

  ngOnInit() {

    this.formPortada.statusChanges.subscribe(newStaus => {
      console.log('newStaus', this.formPortada.value);
      newStaus == 'VALID' ? this.guardarAtributos() : null;
    })
  }

  fileProgress(fileInput: any, tipo) {
    this.fileData = <File>fileInput.target.files[0];
    this.preview(tipo);
  }

  preview(tipo) {
    // Show preview 
    var mimeType = this.fileData.type;
    if (mimeType.match(/image\/*/) == null) {
      return;
    }

    var reader = new FileReader();
    reader.readAsDataURL(this.fileData);
    reader.onload = async (_event) => {

      if (tipo == 'portada') {

        this.formPortada.controls['portadaImg'].setValue(reader.result);
        this.previewUrl = reader.result
      } else {
        this.formPortada.controls['contraPortadaImg'].setValue(reader.result);

        this.contraPortada = reader.result

      }
    }
  }
  uploadFile(event, tipo) {

    var file = (event.target as HTMLInputElement).files[0];
    let extension = file.name.split('.')[file.name.split('.').length - 1];

    // File Preview
    const reader = new FileReader();
    reader.onload = () => {
      //this.preview = reader.result as string;
      if (tipo == 'portada') {

        this.formPortada.controls['portadaImg'].setValue(reader.result);
        this.previewUrl = reader.result;
        this.subirImagen('portadaImg', extension, file);
      } else {
        this.formPortada.controls['contraPortadaImg'].setValue(reader.result);
        this.subirImagen('contraPortadaImg', extension, file);
        this.contraPortada = reader.result

      }

    }
    reader.readAsDataURL(file)
  }


  async subirImagen(tipo, extension, imagen) {
    console.log('tipo', tipo);
    let respuesta = await this.catalogoService.uploadImage(tipo, extension, imagen);
    console.log('respuesta',respuesta);
    tipo == 'portadaImg' ? this.formPortada.controls['urlPortada'].setValue(respuesta.url) : this.formPortada.controls['urlContraPortada'].setValue(respuesta.url);

  }

  async guardarAtributos() {

    let objeto: any = await this.localS.get('catalogo');
    let values = this.formPortada.value;
    
    objeto.portadaImg = await values.urlPortada;
    objeto.contraPortadaImg = await values.urlContraPortada;
    await this.localS.remove('catalogo');
    await this.localS.set('catalogo', objeto);
    console.log('guardo', objeto);
  }

  cargarDatos(objeto: any) {
    if (objeto.portadaImg) {
      this.formPortada.setValue({
        portadaImg: objeto.portadaImg,
        contraPortadaImg: objeto.contraPortadaImg,
        urlPortada:objeto.portadaImg,
        urlContraPortada: objeto.contraPortadaImg
      });
    }



  }
}
