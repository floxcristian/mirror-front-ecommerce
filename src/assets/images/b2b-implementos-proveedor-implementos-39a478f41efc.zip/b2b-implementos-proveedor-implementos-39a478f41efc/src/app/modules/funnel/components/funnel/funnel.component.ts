import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-funnel',
  styleUrls: [`./funnel.component.scss`],
  templateUrl: `./funnel.component.html`
})
export class FunnelComponent {
  public dynamicSlope = false;
  public dynamicHeight = false;
  @Input()
  model:any;
  @Input()
  chartStyle;  
  @Input()
  mobileFlag:boolean
  porcentaje:number


  descripcionCategorias = {
     visitas:' Total de visitantes que entraron a la página de inicio',
     shopping:'Total de visitantes que presionaron alguna categoría,producto u otro link de la página',
     comprobanteCompra:'Total de visitantes vieron su comprobante de compra',
     fichaProducto:'Total de visitantes que vieron la ficha de al menos 1 productos',
     agregarAlCarro:'Total de visitantes que agregaron productos a su carro',
     resumenCarro:'Total de visitanes que usaron el boton Ver Carro',
     metodoEnvio:'Total de visitantes que dieron al botón Comprar, y pasaron a ver los métodos de despacho',
     formaPago:'Total de visitantes que dieron al boton Ir a pagar, y pasaron a ver los medios de pago',
  }
  constructor(){
  }
  ngOnInit(): void {
    if(screen.width>450){
      this.mobileFlag = true
    }else {
      this.mobileFlag = false
    }

  }

/*   onSeriesClick(e){
    console.log(e);
  } */
  onResize(e){
    if(e.target.innerWidth<=450){
      this.mobileFlag = false;
      this.chartStyle = {
        height:'350px',
        width:'200px'  
      }

    }

  }
}



