import { Component, OnInit } from '@angular/core';
import { SolicitudService } from 'src/app/shared/services/solicitudService/solicitud.service';
import { Router } from '@angular/router';
import { pluck } from 'rxjs/operators';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-page-solicitudes-b2b',
  templateUrl: './page-solicitudes-b2b.component.html',
  styleUrls: ['./page-solicitudes-b2b.component.scss']
})
export class PageSolicitudesB2bComponent implements OnInit {

  infoEstadisticasSolicitudes:any
  infoClientes:any[]  
  resp:any;
  mostrarTabla = false;
  innerWidth: number;

  constructor(
    private solicitudService:SolicitudService,
    private router:Router) 
    { 
      this.onResize(event)
    }

  /**Al iniciar el componente extrae la data de los clientes que tiene un solicitud pendiente
   * también las estadisticas de las solicitudes (numero de aprobadas,rechazadas,pendientes)
   */
  ngOnInit() {
    this.solicitudService.getClientesSolicitud().pipe(
      pluck('data')
    ).subscribe((data:any) => this.infoClientes = data)

    this.solicitudService.getEstadisticasSolicitudes().pipe(
      pluck('data')
    ).subscribe(
      (data:any) => this.infoEstadisticasSolicitudes = data)
  }


  /**Aprueba la solicitud de acuerdo al id del cliente*/
  aprobar(cliente:any){
    this.solicitudService.aprobarSolicitud(cliente.id)
      .subscribe(
        (resp:any) => {
           if(resp.error == false){
          Swal.fire("Solicitud Aprobada", `Cliente: ${cliente.nombre} ha sido registrado`, "success")
          this.router.navigate(['/solicitudes'])
        } else {
          Swal.fire("Oops...","Hubo un error!","error")
        }
      }
      )
  }
  
   /**Rechaza la solicitud de acuedo al id del cliente*/
  rechazar(cliente:any){
    this.solicitudService.rechazarSolicitud(cliente.id)
      .subscribe(
        (resp:any) => {
           if(resp.error == false){
          Swal.fire("Solicitud Rechazada", `Cliente: ${cliente.nombre} ha sido Rechazado`, "success")
          this.router.navigate(['/solicitudes'])
        } else {
          Swal.fire("Oops...","Hubo un error!","error")
        }
          
        }
      ) 
  }
  toggleTable(){
   this.mostrarTabla = !this.mostrarTabla
  }
  onResize(event) {

    this.innerWidth = window.innerWidth;
  }
}
