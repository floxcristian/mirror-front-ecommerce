import { Component, OnInit, Input, ViewChild, TemplateRef } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-modal-carro',
  templateUrl: './modal-carro.component.html',
  styleUrls: ['./modal-carro.component.scss']
})
export class ModalCarroComponent implements OnInit {

  @Input()
  modalCarroRef:BsModalRef
  @Input()
  detalleCarro:any;
  
  detalleProductos:any


  @ViewChild('modalProductos') modalProductos: TemplateRef<any>;
  modalProductosRef: BsModalRef;



  constructor(private modalService:BsModalService
    ) { }

  ngOnInit(): void {

  }

  open(productos){
    this.detalleProductos = productos
    this.modalCarroRef.hide()
    this.modalProductosRef = this.modalService.show(this.modalProductos);

  }

}
