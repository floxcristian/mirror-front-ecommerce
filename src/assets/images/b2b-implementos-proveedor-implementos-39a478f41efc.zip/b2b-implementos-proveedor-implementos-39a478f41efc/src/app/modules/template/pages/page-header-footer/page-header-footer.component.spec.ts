import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PageHeaderFooterComponent } from './page-header-footer.component';

describe('PageHeaderFooterComponent', () => {
  let component: PageHeaderFooterComponent;
  let fixture: ComponentFixture<PageHeaderFooterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PageHeaderFooterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PageHeaderFooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
