import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PageUsuariosNuevosComponent } from './pages/page-usuarios-nuevos/page-usuarios-nuevos.component';


const routes: Routes = [

  {
    path: '',
    pathMatch: 'full',
    redirectTo: 'ver-usuarios'
  },
  {
    path: 'ver-usuarios',
    component: PageUsuariosNuevosComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UsuariosNuevosRoutingModule { }
