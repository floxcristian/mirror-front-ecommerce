import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-tabla-usuarios-solicitud',
  templateUrl: './tabla-usuarios-solicitud.component.html',
  styleUrls: ['./tabla-usuarios-solicitud.component.scss']
})
export class TablaUsuariosSolicitudComponent implements OnInit {

  @Input()
  usuariosAprobados;

  constructor() { }

  ngOnInit(): void {
  }

}
