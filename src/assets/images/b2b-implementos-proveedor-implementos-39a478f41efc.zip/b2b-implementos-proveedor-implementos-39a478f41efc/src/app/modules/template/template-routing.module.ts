import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PagePortadaComponent } from './pages/page-portada/page-portada.component';
import { PageCuerpoComponent } from './pages/page-cuerpo/page-cuerpo.component';
import { PageHeaderFooterComponent } from './pages/page-header-footer/page-header-footer.component';



const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    redirectTo: 'crear-portada'
  },
  {
    path: 'crear-portada',
    component:PagePortadaComponent
  },
  {
    path: 'crear-cuerpo',
    component:PageCuerpoComponent
  },
  {
    path: 'crear-footer',
    component:PageHeaderFooterComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TemplateRoutingModule { }
