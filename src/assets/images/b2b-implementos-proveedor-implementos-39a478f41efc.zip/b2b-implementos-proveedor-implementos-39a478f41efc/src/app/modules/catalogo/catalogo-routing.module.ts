import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PageCatalogoComponent } from './pages/page-catalogo/page-catalogo.component';
import { PageAtributosCatalogoComponent } from './pages/page-atributos-catalogo/page-atributos-catalogo.component';
import { PageTemplateCatalogoComponent } from './pages/page-template-catalogo/page-template-catalogo.component';
import { PageProductosCatalogoComponent } from './pages/page-productos-catalogo/page-productos-catalogo.component';
import { PagePreviewCatalogoComponent } from './pages/page-preview-catalogo/page-preview-catalogo.component';
import { PageEnviarCatalogoComponent } from './pages/page-enviar-catalogo/page-enviar-catalogo.component';


const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    redirectTo: 'ver-catalogos'
  },
  {
    path: 'ver-catalogos',
    component: PageCatalogoComponent
  },
  {
    path: 'crear-catalogo',
    component: PageAtributosCatalogoComponent
  },
  {
    path: 'template-catalogo',
    children: [
      {
        path: '',
        loadChildren: () => import('../template/template.module').then(m => m.TemplateModule)
      },
    ],
  },
  {
    path: 'productos-catalogo',
    children: [
      {
        path: '',
        loadChildren: () => import('../productos/productos.module').then(m => m.ProductosModule)
      },
    ],
  },
  {
    path: 'preview-catalogo',
    component: PagePreviewCatalogoComponent
  },
  {
    path: 'enviar-catalogo',
    component: PageEnviarCatalogoComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CatalogoRoutingModule { }
