import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EstadoArticulosRoutingModule } from './estado-articulos-routing.module';
import { PageEstadoArticuloComponent } from './pages/page-estado-articulo/page-estado-articulo.component';
import { SharedModule } from 'src/app/shared/shared.module';


@NgModule({
  declarations: [PageEstadoArticuloComponent],
  imports: [
    CommonModule,
    EstadoArticulosRoutingModule,
    SharedModule
  ]
})
export class EstadoArticulosModule { }
