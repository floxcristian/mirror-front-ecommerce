import { Component, OnInit, Input } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-modal-usuario',
  templateUrl: './modal-usuario.component.html',
  styleUrls: ['./modal-usuario.component.scss']
})
export class ModalUsuarioComponent implements OnInit {

  @Input()
  detalleUsuario:any;
  @Input()
  modalUsuarioRef:BsModalRef

  constructor() { }

  ngOnInit(): void {
  }

}
