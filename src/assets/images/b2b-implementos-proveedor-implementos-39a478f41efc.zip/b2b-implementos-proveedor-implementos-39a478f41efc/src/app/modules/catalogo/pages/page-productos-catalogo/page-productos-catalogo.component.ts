import { Component, OnInit } from '@angular/core';

import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { CatalogoService, Person } from 'src/app/shared/services/catalogoService/catalogo.service';
import { environment } from 'src/environments/environment';
import { Clacom } from 'src/app/shared/interfaces/clacom';
import { map } from 'rxjs/operators';
import { ToastrService } from 'ngx-toastr';
import { OwlOptions } from 'ngx-owl-carousel-o';
import { LocalStorageService } from 'angular-2-local-storage';
@Component({
  selector: 'app-page-productos-catalogo',
  templateUrl: './page-productos-catalogo.component.html',
  styleUrls: ['./page-productos-catalogo.component.scss']
})
export class PageProductosCatalogoComponent  {

}


