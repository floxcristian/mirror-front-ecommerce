import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TablaCarrosPerdidosComponent } from './tabla-carros-perdidos.component';

describe('TablaCarrosPerdidosComponent', () => {
  let component: TablaCarrosPerdidosComponent;
  let fixture: ComponentFixture<TablaCarrosPerdidosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TablaCarrosPerdidosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TablaCarrosPerdidosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
