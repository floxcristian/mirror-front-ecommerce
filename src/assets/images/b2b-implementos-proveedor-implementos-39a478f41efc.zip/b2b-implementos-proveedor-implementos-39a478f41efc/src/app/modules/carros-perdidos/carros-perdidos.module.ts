import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbModule, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { CarrosPerdidosRoutingModule } from './carros-perdidos-routing.module';
import { PageCarrosPerdidosComponent } from './pages/page-carros-perdidos/page-carros-perdidos.component';
import { SharedModule } from '../../shared/shared.module';
import { TablaCarrosPerdidosComponent, NgbdSortableHeader } from './components/tabla-carros-perdidos/tabla-carros-perdidos.component';
import { ModalCarroComponent } from './components/modals/modal-carro/modal-carro.component';
import { ModalProductosComponent } from './components/modals/modal-productos/modal-productos.component';
import { ModalUsuarioComponent } from './components/modals/modal-usuario/modal-usuario.component';
import { ModalRankingComponent } from './components/modals/modal-ranking/modal-ranking.component';



@NgModule({
  providers:[TablaCarrosPerdidosComponent],
  exports:[TablaCarrosPerdidosComponent],
  declarations: [
    PageCarrosPerdidosComponent,
    TablaCarrosPerdidosComponent,
    NgbdSortableHeader,
    ModalCarroComponent,
    ModalProductosComponent,
    ModalUsuarioComponent,
    ModalRankingComponent,
    
    
  ],
  imports: [
    CommonModule,
    CarrosPerdidosRoutingModule,
    SharedModule,
    NgbModule,
    
  ],
  bootstrap:[TablaCarrosPerdidosComponent]
})
export class CarrosPerdidosModule { }