import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PageEstadoArticuloComponent } from './pages/page-estado-articulo/page-estado-articulo.component';


const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    redirectTo: 'estado-articulos'
  },
  {
    path: 'estado-articulos',
    component: PageEstadoArticuloComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EstadoArticulosRoutingModule { }
