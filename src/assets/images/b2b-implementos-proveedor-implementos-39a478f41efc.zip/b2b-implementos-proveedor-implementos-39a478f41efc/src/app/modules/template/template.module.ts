import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TemplateRoutingModule } from './template-routing.module';
import { PageCuerpoComponent } from './pages/page-cuerpo/page-cuerpo.component';
import { PagePortadaComponent } from './pages/page-portada/page-portada.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PageHeaderFooterComponent } from './pages/page-header-footer/page-header-footer.component';
import { LightboxModule } from 'ngx-lightbox';


@NgModule({
  declarations: [PageCuerpoComponent, PagePortadaComponent, PageHeaderFooterComponent],
  imports: [
    CommonModule,
    TemplateRoutingModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    LightboxModule
  ]
})
export class TemplateModule { }
