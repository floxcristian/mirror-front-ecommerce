import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PageFunnelComponent } from './page-funnel.component';

describe('PageFunnelComponent', () => {
  let component: PageFunnelComponent;
  let fixture: ComponentFixture<PageFunnelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PageFunnelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PageFunnelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
