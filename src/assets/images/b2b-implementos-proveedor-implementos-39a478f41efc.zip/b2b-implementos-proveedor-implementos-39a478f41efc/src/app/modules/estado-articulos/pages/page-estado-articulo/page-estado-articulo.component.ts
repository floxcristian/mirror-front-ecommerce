import { Component, OnInit } from '@angular/core';
import { CatalogoService } from 'src/app/shared/services/catalogoService/catalogo.service';

@Component({
  selector: 'app-page-estado-articulo',
  templateUrl: './page-estado-articulo.component.html',
  styleUrls: ['./page-estado-articulo.component.scss']
})
export class PageEstadoArticuloComponent implements OnInit {

  estadoArticulos: any;
  panelOpenState = false;
  innerWidth: number;
  constructor(private catalogService: CatalogoService) {
    this.innerWidth = window.innerWidth;
    console.log('this.innerWidth',this.innerWidth);
  }

  ngOnInit(): void {
    this.catalogService.getEstadoArticulos().subscribe(data => {
      this.estadoArticulos = data.data;
      console.log(this.estadoArticulos);
    });
  }


  onResize(event) {

    this.innerWidth = window.innerWidth;
    console.log('this.innerWidth',this.innerWidth);

  }
}
