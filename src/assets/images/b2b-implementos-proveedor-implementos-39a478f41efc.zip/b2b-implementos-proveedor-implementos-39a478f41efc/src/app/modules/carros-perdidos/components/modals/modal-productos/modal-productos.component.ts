import { Component, OnInit, Input } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-modal-productos',
  templateUrl: './modal-productos.component.html',
  styleUrls: ['./modal-productos.component.scss']
})
export class ModalProductosComponent implements OnInit {

  @Input()
  modalProductosRef:BsModalRef

  @Input()
  detalleProductos:any;

  constructor() { }

  ngOnInit(): void {
  }

}
