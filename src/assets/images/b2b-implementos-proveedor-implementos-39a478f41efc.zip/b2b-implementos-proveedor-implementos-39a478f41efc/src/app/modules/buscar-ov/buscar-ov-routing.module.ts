import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PageBuscarOvComponent } from './pages/page-buscar-ov/page-buscar-ov.component';


const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    redirectTo: 'buscar-ordenes-ventas'
  },
  {
    path: 'buscar-ordenes-ventas',
    component: PageBuscarOvComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BuscarOvRoutingModule { }
