import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PageProductosBannerComponent } from './page-productos-banner.component';

describe('PageProductosBannerComponent', () => {
  let component: PageProductosBannerComponent;
  let fixture: ComponentFixture<PageProductosBannerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PageProductosBannerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PageProductosBannerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
