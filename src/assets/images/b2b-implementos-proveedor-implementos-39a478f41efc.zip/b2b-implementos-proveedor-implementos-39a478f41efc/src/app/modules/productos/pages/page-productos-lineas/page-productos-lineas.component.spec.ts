import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PageProductosLineasComponent } from './page-productos-lineas.component';

describe('PageProductosLineasComponent', () => {
  let component: PageProductosLineasComponent;
  let fixture: ComponentFixture<PageProductosLineasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PageProductosLineasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PageProductosLineasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
