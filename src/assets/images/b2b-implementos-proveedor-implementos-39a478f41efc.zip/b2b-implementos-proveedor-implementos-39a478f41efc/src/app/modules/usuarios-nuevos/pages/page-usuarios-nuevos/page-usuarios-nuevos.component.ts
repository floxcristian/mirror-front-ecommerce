import { Component, OnInit } from '@angular/core';
import { DataEstadisticasUsuarios, DetalleDia, EstadisticasUsuarios } from 'src/app/shared/interfaces/estadisticas-usuarios.model';
import { UsuarioService } from 'src/app/shared/services/usuarioService/usuario.service';
import * as moment from 'moment';
import { map } from 'rxjs/operators';
@Component({
  selector: 'app-page-usuarios-nuevos',
  templateUrl: './page-usuarios-nuevos.component.html',
  styleUrls: ['./page-usuarios-nuevos.component.scss']
})
export class PageUsuariosNuevosComponent implements OnInit {

 
  estadisticasUsuarios:DataEstadisticasUsuarios;
  detalleDia:DetalleDia[] = [];
  hoy = new Date()

  constructor(private usuarioService:UsuarioService) { }

  /**Al iniciar el componente extrae las estadisitcas de los usuarios registrados en el B2B
   * guarda el detalle diario y el historico
   */

  ngOnInit() {
    let fechas = {
      inicio: moment().startOf('day').toISOString(),
      termino: moment().endOf('day').toISOString()
    }
 
    this.usuarioService.EstadisticasUsuarios(fechas).pipe(
      map( (data:EstadisticasUsuarios) => {
        for(let i in data.data.detalleDia){
          if(data.data.detalleDia[i] != null){
            this.detalleDia.push(data.data.detalleDia[i])
          }
        }
        this.estadisticasUsuarios = data.data})
    ).subscribe()
  }
  /**Calcula en porcentaje que falta para alcanzar al total de usuarios del mes anterior */
  getPorcentaje(){
   let porcentajeMesActual = ((this.estadisticasUsuarios.mes.total*100)/this.estadisticasUsuarios.mesAnterior.total);
   let comparacion = ((porcentajeMesActual-100) *-1)
   return Math.round(comparacion)
  }

}
