import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PageFunnelComponent } from './pages/page-funnel/page-funnel.component';


const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    redirectTo: 'ver-funnel'
  },
  {
    path: 'ver-funnel',
    component: PageFunnelComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FunnelRoutingModule { }
