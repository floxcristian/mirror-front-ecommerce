import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PageCuerpoComponent } from './page-cuerpo.component';

describe('PageCuerpoComponent', () => {
  let component: PageCuerpoComponent;
  let fixture: ComponentFixture<PageCuerpoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PageCuerpoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PageCuerpoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
