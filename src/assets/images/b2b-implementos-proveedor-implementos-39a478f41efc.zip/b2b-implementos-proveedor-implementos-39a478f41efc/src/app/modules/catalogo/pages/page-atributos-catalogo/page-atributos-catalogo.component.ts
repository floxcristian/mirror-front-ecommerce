import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { LocalStorageService } from 'angular-2-local-storage';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-page-atributos-catalogo',
  templateUrl: './page-atributos-catalogo.component.html',
  styleUrls: ['./page-atributos-catalogo.component.scss']
})
export class PageAtributosCatalogoComponent implements OnInit {

  formCatalogo : FormGroup;
  distribuciones =['publico','privado','cliente'];
  tipoCatalogos =['mensual','productos nuevos','liquidables','propuesta'];
  constructor(private fb : FormBuilder,private localS : LocalStorageService, private toast: ToastrService) { 
    this.formCatalogo = this.fb.group({
      nombre : new FormControl(null,[Validators.required]),
      autor : new FormControl(null,[Validators.required]),
      fechaEx : new FormControl(null,[Validators.required]),
      distribucion : new FormControl(null,[Validators.required]),
      tipoCatalogo : new FormControl(null,[Validators.required]),
      objetivo : new FormControl(null),
    })
    let objeto: any = localS.get('catalogo');
    this.cargarDatos(objeto);
  }

  ngOnInit() {
    console.log('formCatalogo',this.formCatalogo);
  }
  guardarAtributos(){
    let form = this.formCatalogo.value;
    let catalogo =form;
    this.localS.set('catalogo',catalogo);
    this.toast.success('Se almacenaron correctamente los datos');
  }

  cargarDatos(objeto: any) {
    /* if(objeto.nombre){
      this.formCatalogo.setValue({
        nombre:objeto.nombre,
        autor:objeto.autor,
        fechaEx:objeto.fechaEx,
        distribucion:objeto.distribucion,
        tipoCatalogo:objeto.tipoCatalogo,
        objetivo:objeto.objetivo
       })
    } */
   
  }
}
