import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { environment } from 'src/environments/environment';
import { LocalStorageService } from 'angular-2-local-storage';
import { Lightbox } from 'ngx-lightbox';

@Component({
  selector: 'app-page-cuerpo',
  templateUrl: './page-cuerpo.component.html',
  styleUrls: ['./page-cuerpo.component.scss']
})
export class PageCuerpoComponent implements OnInit {

  formTemplate : FormGroup;
  templates = environment.template;
  private albums: Array<any> = [];
  constructor(private fb : FormBuilder, private localS: LocalStorageService,private lightbox: Lightbox) { 
    this.formTemplate = this.fb.group({
      template : new FormControl(null, Validators.required)
    })
    let objeto : any = localS.get('catalogo');
    this.cargarDatos(objeto);
     /*  this.templates.map(imagen=>{
        const src = imagen.foto;
        const caption = imagen.titulo;
        const thumb = imagen.foto;
        const album = {
           src: src,
           caption: caption,
           thumb: thumb
        };
   
        this.albums.push(album);
      }) */
      for (let i = 0; i < this.templates.length; i++) {
        const src = this.templates[i].foto;
        const caption = 'Image ' + this.templates[i].titulo;
        const thumb = this.templates[i].foto;
        const album = {
           src: src,
           caption: caption,
           thumb: thumb
        };
   
        this.albums.push(album);
      }
    
  }



  ngOnInit(): void {
    this.formTemplate.statusChanges.subscribe(newStaus => {
      newStaus=='VALID'?this.guardarAtributos():null;
    })
  }


  async guardarAtributos() {
    let objeto: any = await this.localS.get('catalogo');
    objeto.template= this.formTemplate.value.template;
    let template :any = this.templates.filter(template=>template.value==objeto.template);
    console.log(template);
    objeto.atributos =template[0].atributos;
    await this.localS.remove('catalogo');
    await this.localS.set('catalogo', objeto);
    console.log('guardo',objeto);
  }

  cargarDatos(objeto: any) {
    if(objeto.template){
      this.formTemplate.controls['template'].setValue(objeto.template);
    }
  }

  abrir(i: number): void {
    console.log('aqui',this.albums);
      // open lightbox
      this.lightbox.open(this.albums, i);
    }
}
