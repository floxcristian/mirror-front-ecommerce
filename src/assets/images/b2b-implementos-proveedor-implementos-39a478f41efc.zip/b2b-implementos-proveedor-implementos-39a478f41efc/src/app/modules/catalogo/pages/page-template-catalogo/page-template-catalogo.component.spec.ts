import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PageTemplateCatalogoComponent } from './page-template-catalogo.component';

describe('PageTemplateCatalogoComponent', () => {
  let component: PageTemplateCatalogoComponent;
  let fixture: ComponentFixture<PageTemplateCatalogoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PageTemplateCatalogoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PageTemplateCatalogoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
