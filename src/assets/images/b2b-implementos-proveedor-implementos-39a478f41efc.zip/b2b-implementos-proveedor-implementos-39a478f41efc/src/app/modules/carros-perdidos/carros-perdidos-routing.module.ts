import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PageCarrosPerdidosComponent } from './pages/page-carros-perdidos/page-carros-perdidos.component';


const routes: Routes = [

  {
    path: '',
    pathMatch: 'full',
    redirectTo: 'ver-carros-perdidos'
  },
  {
    path: 'ver-carros-perdidos',
    component: PageCarrosPerdidosComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CarrosPerdidosRoutingModule { }