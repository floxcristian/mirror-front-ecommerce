import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ResumenRoutingModule } from './resumen-routing.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from 'src/app/shared/shared.module';
import { PageResumenComponent } from './pages/page-resumen/page-resumen.component';


@NgModule({
  /* providers:[PageResumenComponent], */
  declarations: [PageResumenComponent],
  imports: [
    CommonModule,
    ResumenRoutingModule,
    NgbModule,
    SharedModule
  ],
  exports:[PageResumenComponent],
  bootstrap:[PageResumenComponent]
})
export class ResumenModule { }
