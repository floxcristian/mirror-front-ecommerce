import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PageBuscarOvComponent } from './page-buscar-ov.component';

describe('PageBuscarOvComponent', () => {
  let component: PageBuscarOvComponent;
  let fixture: ComponentFixture<PageBuscarOvComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PageBuscarOvComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PageBuscarOvComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
