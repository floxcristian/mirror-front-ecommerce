import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-template-tabla-productos',
  templateUrl: './template-tabla-productos.component.html',
  styleUrls: ['./template-tabla-productos.component.scss']
})
export class TemplateTablaProductosComponent implements OnInit {

  @Input()objeto : any;

  constructor() { }

  ngOnInit(): void {
    console.log(this.objeto);
  }

}
