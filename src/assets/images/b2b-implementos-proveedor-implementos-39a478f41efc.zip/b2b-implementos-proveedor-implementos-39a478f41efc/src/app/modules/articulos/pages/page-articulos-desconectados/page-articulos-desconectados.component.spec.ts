import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PageArticulosDesconectadosComponent } from './page-articulos-desconectados.component';

describe('PageArticulosDesconectadosComponent', () => {
  let component: PageArticulosDesconectadosComponent;
  let fixture: ComponentFixture<PageArticulosDesconectadosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PageArticulosDesconectadosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PageArticulosDesconectadosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
