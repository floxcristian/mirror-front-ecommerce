import { Component, OnInit, Input } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-modal-ranking',
  templateUrl: './modal-ranking.component.html',
  styleUrls: ['./modal-ranking.component.scss']
})
export class ModalRankingComponent implements OnInit {

  @Input()
  modalRankingRef:BsModalRef

  @Input()
  infoRanking:any;

  totalItems: number;
  page: number = 1;
  pageSize:number = 8;

  constructor() { }

  ngOnInit(): void {
  }

}
