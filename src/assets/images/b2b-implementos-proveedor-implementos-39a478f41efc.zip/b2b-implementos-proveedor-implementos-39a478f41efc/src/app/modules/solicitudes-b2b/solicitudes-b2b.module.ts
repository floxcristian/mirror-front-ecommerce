import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SolicitudesB2bRoutingModule } from './solicitudes-b2b-routing.module';
import { PageSolicitudesB2bComponent } from './pages/page-solicitudes-b2b/page-solicitudes-b2b.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { TablaUsuariosSolicitudComponent } from './components/tabla-usuarios-solicitud/tabla-usuarios-solicitud.component';


@NgModule({
  declarations: [
    PageSolicitudesB2bComponent,
    TablaUsuariosSolicitudComponent
  ],
  imports: [
    CommonModule,
    SolicitudesB2bRoutingModule,
    SharedModule
  ]
})
export class SolicitudesB2bModule { }
