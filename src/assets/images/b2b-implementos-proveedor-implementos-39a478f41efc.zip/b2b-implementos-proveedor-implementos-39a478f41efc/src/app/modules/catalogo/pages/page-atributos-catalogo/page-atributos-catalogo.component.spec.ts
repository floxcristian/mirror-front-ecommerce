import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PageAtributosCatalogoComponent } from './page-atributos-catalogo.component';

describe('PageAtributosCatalogoComponent', () => {
  let component: PageAtributosCatalogoComponent;
  let fixture: ComponentFixture<PageAtributosCatalogoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PageAtributosCatalogoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PageAtributosCatalogoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
