import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PageCarrosPerdidosComponent } from './page-carros-perdidos.component';

describe('PageCarrosPerdidosComponent', () => {
  let component: PageCarrosPerdidosComponent;
  let fixture: ComponentFixture<PageCarrosPerdidosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PageCarrosPerdidosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PageCarrosPerdidosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
