import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PagePortadaComponent } from './page-portada.component';

describe('PagePortadaComponent', () => {
  let component: PagePortadaComponent;
  let fixture: ComponentFixture<PagePortadaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PagePortadaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PagePortadaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
