import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-template-productos-vertical',
  templateUrl: './template-productos-vertical.component.html',
  styleUrls: ['./template-productos-vertical.component.scss']
})
export class TemplateProductosVerticalComponent implements OnInit {
  @Input()objeto : any;

  constructor() { }

  ngOnInit(): void {
    console.log(this.objeto);
  }

}
