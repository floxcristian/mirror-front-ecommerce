import { Component, OnInit } from '@angular/core';
import { LocalStorageService } from 'angular-2-local-storage';

@Component({
  selector: 'app-page-preview-catalogo',
  templateUrl: './page-preview-catalogo.component.html',
  styleUrls: ['./page-preview-catalogo.component.scss']
})
export class PagePreviewCatalogoComponent implements OnInit {
  catalogo :any=[
 
  ];
  objeto : any
  objetoL : any;
  auxObjeto:any
  page: number;
  constructor(private localS:LocalStorageService) { 
    this.page =0;
    this.auxObjeto = this.localS.get('catalogo');
    this.catalogo = this.localS.get('preview');
   
    this.objeto = this.catalogo[this.page];
  
  }

  ngOnInit() {
    
  }

  cambiarPagina(valor){

    valor?this.page+=1:this.page-=1;
    this.objeto = this.catalogo[this.page];
 
  }
  Reset(valor){
    valor?this.page=0:this.page=this.catalogo.length-1;
    this.objeto = this.catalogo[this.page];
  }
}
