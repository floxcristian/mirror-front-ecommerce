import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PagePreviewCatalogoComponent } from './page-preview-catalogo.component';

describe('PagePreviewCatalogoComponent', () => {
  let component: PagePreviewCatalogoComponent;
  let fixture: ComponentFixture<PagePreviewCatalogoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PagePreviewCatalogoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PagePreviewCatalogoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
