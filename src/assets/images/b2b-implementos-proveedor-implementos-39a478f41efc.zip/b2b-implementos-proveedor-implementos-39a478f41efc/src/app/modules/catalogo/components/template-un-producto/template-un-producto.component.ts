import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-template-un-producto',
  templateUrl: './template-un-producto.component.html',
  styleUrls: ['./template-un-producto.component.scss']
})
export class TemplateUnProductoComponent implements OnInit {
  @Input()objeto : any;
  constructor() { }

  ngOnInit(): void {
    console.log('un',this.objeto);
  }

}
