import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BuscarOvRoutingModule } from './buscar-ov-routing.module';
import { PageBuscarOvComponent } from './pages/page-buscar-ov/page-buscar-ov.component';
import { SharedModule } from 'src/app/shared/shared.module';


@NgModule({
  declarations: [PageBuscarOvComponent],
  imports: [
    CommonModule,
    BuscarOvRoutingModule,
    SharedModule
  ]
})
export class BuscarOvModule { }
