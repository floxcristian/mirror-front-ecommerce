import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PageSolicitudesB2bComponent } from './page-solicitudes-b2b.component';

describe('PageSolicitudesB2bComponent', () => {
  let component: PageSolicitudesB2bComponent;
  let fixture: ComponentFixture<PageSolicitudesB2bComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PageSolicitudesB2bComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PageSolicitudesB2bComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
