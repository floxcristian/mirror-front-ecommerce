import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminComponent } from 'src/app/theme/layout/admin/admin.component';
import { AutenticacionGuard } from 'src/app/shared/guard/autenticacion.guard';
import { PageArticulosDesconectadosComponent } from './pages/page-articulos-desconectados/page-articulos-desconectados.component';


const routes: Routes = [
  {
    path: 'articulos',
    component: AdminComponent,
    data: {
      headerLayout: 'classic'
    },
    children: [
      {
        path: '',
        pathMatch: 'full',
        redirectTo: 'articulos-desconectados',
      },
      {
        path: 'articulos-desconectados',
        component: PageArticulosDesconectadosComponent
      }
    ],
    canActivate: [AutenticacionGuard]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ArticulosRoutingModule { }
