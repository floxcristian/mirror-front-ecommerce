import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-page-template-catalogo',
  templateUrl: './page-template-catalogo.component.html',
  styleUrls: ['./page-template-catalogo.component.scss']
})
export class PageTemplateCatalogoComponent implements OnInit {
  
  ngOnInit() {
  }

}
