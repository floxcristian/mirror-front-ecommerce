import { Component, OnInit } from '@angular/core';
import { LocalStorageService } from 'angular-2-local-storage';
import { CatalogoService } from 'src/app/shared/services/catalogoService/catalogo.service';


@Component({
  selector: 'app-page-productos-cargados',
  templateUrl: './page-productos-cargados.component.html',
  styleUrls: ['./page-productos-cargados.component.scss']
})
export class PageProductosCargadosComponent implements OnInit {
  productosObtenidos: Array<any> =[];
  auxObjeto: any;
  constructor( private localS: LocalStorageService, private catalogoService: CatalogoService) { 
    this.auxObjeto = this.localS.get('catalogo');


    this.cargarDatos(this.auxObjeto);
  }

  async ngOnInit() {
    let objeto: any = this.localS.get('catalogo');
    console.log('objeto',objeto);
     let respuesta = await this.catalogoService.generarCatalogo(objeto);
   
    console.log('respuesta banner',respuesta);
    this.localS.remove('preview');
    this.localS.set('preview',respuesta);
    let catalogo = this.localS.get('preview');
    console.log('catalogo',catalogo); 
  }
  cargarDatos(objeto: any) {
  
    this.productosObtenidos = objeto.prodObtenidos;
 
    console.log('this.productosObtenidos ',this.productosObtenidos );
    /*  this.productosObtenidos.map(prod=>{

      let filtro = prod.productos.filter(prd=>prd.imagen==true);
      prod.productos= filtro
  
    })  */
  }
}
