import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AutenticacionService } from 'src/app/shared/services/autenticacionService/autenticacion.service';

@Component({
  selector: 'app-page-iniciar-sesion',
  templateUrl: './page-iniciar-sesion.component.html',
  styleUrls: ['./page-iniciar-sesion.component.scss']
})
export class PageIniciarSesionComponent implements OnInit {
  loginForm: FormGroup;
  loading = false;
  submitted = false;
  returnUrl: string;
  error: string;
  innerWidth:number;
  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private autentificacionService: AutenticacionService
  ) {
    // redirect to home if already logged in
    if (this.autentificacionService.currentUserValue) {
      this.router.navigate(['/']);
    }
    this.innerWidth = window.innerWidth;
  }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });

    // get return url from route parameters or default to '/'
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
  }

  // convenience getter for easy access to form fields
  get f() { return this.loginForm.controls; }

  async onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.loginForm.invalid) {
      return;
    }

    this.loading = true;
    let usuarioLogin = {
      strUsuario: this.f.username.value,
      strPassword: this.f.password.value
    }
    
    let respuesta = await this.autentificacionService.login(usuarioLogin);
    console.log('respuesta', respuesta);
    if (respuesta) {
      this.router.navigate(['/resumen']);
    } else {
      this.error = 'usuario/contraseña incorrecto';
      this.loading = false;
    }
  }
  onResize(event) {

    this.innerWidth = window.innerWidth;
  }
}
