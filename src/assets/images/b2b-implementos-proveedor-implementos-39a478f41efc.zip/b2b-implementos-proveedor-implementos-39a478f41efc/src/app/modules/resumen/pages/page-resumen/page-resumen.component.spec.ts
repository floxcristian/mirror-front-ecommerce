import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PageResumenComponent } from './page-resumen.component';

describe('PageResumenComponent', () => {
  let component: PageResumenComponent;
  let fixture: ComponentFixture<PageResumenComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PageResumenComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PageResumenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
