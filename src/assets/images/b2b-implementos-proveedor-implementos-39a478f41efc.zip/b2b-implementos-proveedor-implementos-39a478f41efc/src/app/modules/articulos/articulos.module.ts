import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ArticulosRoutingModule } from './articulos-routing.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { SharedModule } from 'src/app/shared/shared.module';
import { PageArticulosDesconectadosComponent } from './pages/page-articulos-desconectados/page-articulos-desconectados.component';
import { NgxSpinnersModule } from 'ngx-spinners';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  declarations: [
    PageArticulosDesconectadosComponent
  ],
  imports: [
    CommonModule,
    ArticulosRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    SharedModule,
    NgxSpinnersModule,
    NgbModule
  ]
})
export class ArticulosModule { }
