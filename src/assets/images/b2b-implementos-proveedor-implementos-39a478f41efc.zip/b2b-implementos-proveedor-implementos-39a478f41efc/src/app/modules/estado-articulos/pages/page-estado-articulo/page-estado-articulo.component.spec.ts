import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PageEstadoArticuloComponent } from './page-estado-articulo.component';

describe('PageEstadoArticuloComponent', () => {
  let component: PageEstadoArticuloComponent;
  let fixture: ComponentFixture<PageEstadoArticuloComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PageEstadoArticuloComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PageEstadoArticuloComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
