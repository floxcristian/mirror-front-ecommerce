import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AutenticacionRoutingModule } from './autenticacion-routing.module';
import { PageIniciarSesionComponent } from './pages/page-iniciar-sesion/page-iniciar-sesion.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';


@NgModule({
  declarations: [PageIniciarSesionComponent],
  imports: [
    CommonModule,
    AutenticacionRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    SharedModule,
    
  ]
})
export class AutenticacionModule { }
