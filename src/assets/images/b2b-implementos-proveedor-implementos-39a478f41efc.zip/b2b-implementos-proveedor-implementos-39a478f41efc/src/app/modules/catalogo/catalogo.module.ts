import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CatalogoRoutingModule } from './catalogo-routing.module';
import { PageCatalogoComponent } from './pages/page-catalogo/page-catalogo.component';
import { PageTemplateCatalogoComponent } from './pages/page-template-catalogo/page-template-catalogo.component';
import { PageAtributosCatalogoComponent } from './pages/page-atributos-catalogo/page-atributos-catalogo.component';
import { PageProductosCatalogoComponent } from './pages/page-productos-catalogo/page-productos-catalogo.component';
import { PageEnviarCatalogoComponent } from './pages/page-enviar-catalogo/page-enviar-catalogo.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { PagePreviewCatalogoComponent } from './pages/page-preview-catalogo/page-preview-catalogo.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { NgSelectModule } from '@ng-select/ng-select';

import { TemplatePortadaComponent } from './components/template-portada/template-portada.component';
import { TemplateUnProductoComponent } from './components/template-un-producto/template-un-producto.component';
import { TemplateTablaProductosComponent } from './components/template-tabla-productos/template-tabla-productos.component';
import { TemplateProductosVerticalComponent } from './components/template-productos-vertical/template-productos-vertical.component';
import { TemplateProductosHorizontalComponent } from './components/template-productos-horizontal/template-productos-horizontal.component';


@NgModule({
  declarations: [
    PageCatalogoComponent, 
    PageTemplateCatalogoComponent, 
    PageAtributosCatalogoComponent, 
    PageProductosCatalogoComponent, 
    PageEnviarCatalogoComponent, 
    PagePreviewCatalogoComponent,
 
    TemplatePortadaComponent,
    TemplateUnProductoComponent,
    TemplateTablaProductosComponent,
    TemplateProductosVerticalComponent,
    TemplateProductosHorizontalComponent,
 
  
  ],
  imports: [
    CommonModule,
    CatalogoRoutingModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,

    NgSelectModule,
    
  ],
  exports: [
    PageCatalogoComponent,
    TemplatePortadaComponent,
    TemplateUnProductoComponent,
    TemplateTablaProductosComponent,
    TemplateProductosVerticalComponent,
    TemplateProductosHorizontalComponent,
  ]
})
export class CatalogoModule { }
