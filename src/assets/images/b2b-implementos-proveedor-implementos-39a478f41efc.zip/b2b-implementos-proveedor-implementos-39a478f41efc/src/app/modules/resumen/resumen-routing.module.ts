import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PageResumenComponent } from './pages/page-resumen/page-resumen.component';
import { AdminComponent } from 'src/app/theme/layout/admin/admin.component';
import { AutenticacionGuard } from 'src/app/shared/guard/autenticacion.guard';


const routes: Routes = [
  {
    path: 'resumen',
    component: AdminComponent,
    data: {
      headerLayout: 'classic'
    },
    children: [
      {
        path: '',
        pathMatch: 'full',
        redirectTo: 'ver-resumen',
      },
      {
        path: 'ver-resumen',
        component: PageResumenComponent
      }
    ],
    canActivate: [AutenticacionGuard]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ResumenRoutingModule { }
