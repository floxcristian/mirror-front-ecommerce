import { Component, OnInit, Input } from '@angular/core';
import { DataInfoVenta, InfoVenta } from '../../../../shared/models/info-ventas.model';
import * as moment from 'moment';
import { CarroService } from '../../../../shared/services/carro.service';
import { Router } from '@angular/router';
import{tap,scan} from 'rxjs/operators';
import { from} from 'rxjs';
import { NgbDate} from '@ng-bootstrap/ng-bootstrap';



@Component({
  selector: 'app-dash-default',
  templateUrl: './page-resumen.component.html',
  styleUrls: ['./page-resumen.component.scss']
})
export class PageResumenComponent implements OnInit {

  chartData:any

  infoVentas: DataInfoVenta
  infoVentasMesAnterior:DataInfoVenta
  fechaInicio:NgbDate
  fechaTermino:NgbDate
  mesPasado  = new Date()
  mostrarTablaVentas = false;
  modalState = false;
  anchoScreen: number;
  tipoDetalle: string;
  archivo:string;
  filtro = false;
  percent:number
  desde="Desde";
  hasta="Hasta";
  ventaDiaActualMesAnterior:any;
  diaActualMesAnterior:number
  loading:boolean = false;


  fechas = {
    inicio: moment().startOf('day').toISOString(),
    termino: moment().endOf('day').toISOString()
  }
  arregloVentaDiaria:any ={
    data:[],
    label: moment().locale('es').startOf("month").format('MMMM').toUpperCase()
  }
  arregloVentaDiariaMesAnterior = {
    data:[],
    label: moment().locale('es').subtract(1, "month").startOf("month").format('MMMM').toUpperCase()
  }
  ventaMesActualAcumulada = {
    name: "Venta Acumulada: "+ moment().locale('es').startOf("month").format('MMMM').toUpperCase(),
    data:[],

  }
  ventaMesAnteriorAcumulada = {
    name:  "Venta Acumulada: "+ moment().locale('es').subtract(1, "month").startOf("month").format('MMMM').toUpperCase(),
    data:[],

  }

   mesAnterior = moment().subtract(1,'months') 


  


  constructor(
    private carroService: CarroService,  
    private router: Router
  ) {
    this.chartData = this.seoChartData

  }

  ngOnInit() {
    this.loading = true
    this.carroService.estadisticasFecha(this.fechas).pipe(
      tap((data: InfoVenta) => {
        this.infoVentas = data.data
        for (let i in this.infoVentas.detalleMes.detalleDias) {
          this.arregloVentaDiaria.data.push(parseInt(Object.values(this.infoVentas.detalleMes.detalleDias[i])[0]))
        }
        for (let i in this.infoVentas.detalleMesAnterior.detalleDias) {
          this.arregloVentaDiariaMesAnterior.data.push(parseInt(Object.values(this.infoVentas.detalleMesAnterior.detalleDias[i])[0]))
        }
        })
    ).subscribe( ()=>{
      let acumulador = (acc,cur) => acc + cur
      let accumAnterior;
      let accumActual;
      accumAnterior = this.arregloVentaDiariaMesAnterior.data;
      accumActual = this.arregloVentaDiaria.data
      from( accumAnterior ).pipe(scan(acumulador,0)).subscribe( data => this.ventaMesAnteriorAcumulada.data.push(data))
      from( accumActual ).pipe(scan(acumulador,0)).subscribe( data => this.ventaMesActualAcumulada.data.push(data))
      this.ventaAlDiaMesAnterior();
      this.getPorcentaje()
      this.loading = false

    })
  }

  getVentaDiaria() {
    return this.arregloVentaDiaria
  }
   getVentaDiariaMesAnterior(){
    return this.arregloVentaDiariaMesAnterior
  }
  getVentaAcumuladaAnterior(){
    return this.ventaMesAnteriorAcumulada
  }
  getVentaAcumuladaActual(){
    return this.ventaMesActualAcumulada
  }
  /**  Cálculo del porcentaje que falta para alcanzar en ventas al mes Anterior */
  getPorcentaje(){
    let porcentajeMesActual = ((this.infoVentas.detalleMes.sumaMes*100)/this.ventaDiaActualMesAnterior);
    let comparacion = ((porcentajeMesActual-100) *-1)
    this.percent = Math.round(comparacion)
  }
  ventaAlDiaMesAnterior(){
    let hoy =Number(moment().startOf('day').format('D'))
    let dia = 1;
    for(let i in this.ventaMesAnteriorAcumulada.data){
      dia++
      if(hoy == dia ){
        this.diaActualMesAnterior = dia
      }
    }
    if(this.ventaMesAnteriorAcumulada.data[this.diaActualMesAnterior-1]){
      this.ventaDiaActualMesAnterior = this.ventaMesAnteriorAcumulada.data[this.diaActualMesAnterior-1]
    } else {
      this.ventaDiaActualMesAnterior = 'El mes anterior no tiene dia 31'
    }
  }

  async toggleTable(tipo: string) {  
    this.anchoScreen = screen.width;
    switch(tipo){
      case "B2B": this.tipoDetalle = "B2B";
      this.mostrarTablaVentas = true
      break;
      case "B2C": this.tipoDetalle = "B2C";
      this.mostrarTablaVentas = true
      break;
      case "TODOS": this.tipoDetalle = "TODOS"
      this.mostrarTablaVentas = true
      break;
    }
  }

  async filtrarFechas(){
    this.loading = true

    let fechaInicio =  new Date(this.fechaInicio.year, this.fechaInicio.month - 1, this.fechaInicio.day).toISOString();
    let fechaTermino =  new Date(this.fechaTermino.year, this.fechaTermino.month - 1, this.fechaTermino.day).toISOString();
     this.fechas = {
      inicio: moment(fechaInicio).startOf('day').toISOString(),
      termino: moment(fechaTermino).endOf('day').toISOString() 
    }
    this.filtro = true;
      await this.carroService.estadisticasFecha(this.fechas).pipe(
        tap((data: InfoVenta) => {
          this.infoVentas = data.data
          this.getPorcentaje()
          this.loading = false;
        })
      ).toPromise()
    

  }

    seoChartData = {
      chart: {
        height: 350,
        type: 'area',
        background:'light',
      },
      dataLabels: {
        enabled: false
      },
      stroke: {
        curve: 'smooth'
      },
      colors: ['#ffa21d', '#ff5252'],
      series: [
        this.ventaMesActualAcumulada,
        this.ventaMesAnteriorAcumulada],
  
      xaxis: {
          type:'numeric',
          hideOverlappingLabels:true,

        },
      tooltip: {

      }
    };
}

