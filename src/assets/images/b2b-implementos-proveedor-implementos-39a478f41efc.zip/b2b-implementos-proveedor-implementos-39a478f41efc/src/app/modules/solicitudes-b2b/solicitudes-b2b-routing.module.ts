import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PageSolicitudesB2bComponent } from './pages/page-solicitudes-b2b/page-solicitudes-b2b.component';


const routes: Routes = [

  {
    path: '',
    pathMatch: 'full',
    redirectTo: 'ver-solicitudes'
  },
  {
    path: 'ver-solicitudes',
    component: PageSolicitudesB2bComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SolicitudesB2bRoutingModule { }
