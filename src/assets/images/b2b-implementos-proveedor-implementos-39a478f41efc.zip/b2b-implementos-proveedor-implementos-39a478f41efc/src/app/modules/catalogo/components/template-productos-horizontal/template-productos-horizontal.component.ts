import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-template-productos-horizontal',
  templateUrl: './template-productos-horizontal.component.html',
  styleUrls: ['./template-productos-horizontal.component.scss']
})
export class TemplateProductosHorizontalComponent implements OnInit {
  @Input()objeto : any;

  constructor() { }

  ngOnInit(): void {
    console.log('objeto',this.objeto);
  }

}
