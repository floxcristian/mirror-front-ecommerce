import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PageProductosCatalogoComponent } from './page-productos-catalogo.component';

describe('PageProductosCatalogoComponent', () => {
  let component: PageProductosCatalogoComponent;
  let fixture: ComponentFixture<PageProductosCatalogoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PageProductosCatalogoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PageProductosCatalogoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
