import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PageIniciarSesionComponent } from './pages/page-iniciar-sesion/page-iniciar-sesion.component';


const routes: Routes = [
 
  {
    path: 'autenticacion',

    data: {
      headerLayout: 'classic'
    },
    children: [
      {
        path: '',
        pathMatch: 'full',
        redirectTo: 'inciar-sesion',
      },
      {
        path: 'inciar-sesion',
        component: PageIniciarSesionComponent
      }
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AutenticacionRoutingModule { }
