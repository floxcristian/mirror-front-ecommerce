import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TablaUsuariosSolicitudComponent } from './tabla-usuarios-solicitud.component';

describe('TablaUsuariosSolicitudComponent', () => {
  let component: TablaUsuariosSolicitudComponent;
  let fixture: ComponentFixture<TablaUsuariosSolicitudComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TablaUsuariosSolicitudComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TablaUsuariosSolicitudComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
