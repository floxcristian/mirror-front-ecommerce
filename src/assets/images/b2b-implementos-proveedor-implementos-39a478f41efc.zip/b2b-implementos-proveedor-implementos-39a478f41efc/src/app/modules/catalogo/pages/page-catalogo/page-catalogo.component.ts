import { Component, OnInit } from '@angular/core';
import { CatalogoService } from 'src/app/shared/services/catalogoService/catalogo.service';
import { LocalStorageService } from 'angular-2-local-storage';
import { Router } from '@angular/router';

@Component({
  selector: 'app-page-catalogo',
  templateUrl: './page-catalogo.component.html',
  styleUrls: ['./page-catalogo.component.scss']
})
export class PageCatalogoComponent implements OnInit {
  lstCatalogos : Array<any>[];

  constructor(private catalogoService : CatalogoService,private localS : LocalStorageService, private router: Router) { }

  async ngOnInit() {
    let consulta  =await this.catalogoService.obtenerCatalogos();
    console.log(consulta);
    this.lstCatalogos = consulta;
  }
  verCatalogo(catalogo){
    console.log('catalogo',catalogo);
    this.localS.set('preview',catalogo.cuerpo);
    this.router.navigate(['/','admin','catalogo','preview-catalogo']);
  }

}
