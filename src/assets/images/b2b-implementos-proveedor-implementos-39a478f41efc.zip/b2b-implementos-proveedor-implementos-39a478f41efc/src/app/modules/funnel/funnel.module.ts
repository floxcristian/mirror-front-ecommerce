import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
   // Imports the Chart module  
   import { ChartModule } from '@progress/kendo-angular-charts';

   // Imports the Sparkline module
import { SparklineModule } from '@progress/kendo-angular-charts'

import { NgbDate, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FunnelRoutingModule } from './funnel-routing.module';
import { PageFunnelComponent } from './pages/page-funnel/page-funnel.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { FunnelComponent } from './components/funnel/funnel.component';
import 'hammerjs';
import { FormsModule } from '@angular/forms';








@NgModule({
  providers:[FunnelComponent,CommonModule],
  exports:[FunnelComponent,NgbModule,CommonModule,ChartModule],
  declarations: [
    PageFunnelComponent,
    FunnelComponent

  ],
  imports: [
    CommonModule,
    FormsModule,
    NgbModule,
    ChartModule,
    FunnelRoutingModule,
    SharedModule,
    SparklineModule
    
    
  ],
  bootstrap:[FunnelComponent]
})
export class FunnelModule { }
