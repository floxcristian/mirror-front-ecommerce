import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { LocalStorageService } from 'angular-2-local-storage';
import { CatalogoService } from 'src/app/shared/services/catalogoService/catalogo.service';

@Component({
  selector: 'app-page-productos-banner',
  templateUrl: './page-productos-banner.component.html',
  styleUrls: ['./page-productos-banner.component.scss']
})
export class PageProductosBannerComponent implements OnInit {
  productosObtenidos: Array<any> =[];
  
  formbanner: FormGroup;
  fileData: File = null;
  previewUrl: any = null;
  contraPortada: any = null;
  fileUploadProgress: string = null;
  uploadedFilePath: string = null;
  banner: any = null;
  constructor(private fb: FormBuilder, private localS: LocalStorageService, private catalogoService: CatalogoService) {
    this.formbanner = this.fb.group({
    });
    let objeto: any = localS.get('catalogo');
    console.log(objeto);
    this.cargarDatos(objeto);
  }

  ngOnInit() {
    this.formbanner.statusChanges.subscribe(newStaus => {
      newStaus == 'VALID' ? this.guardarAtributos() : null;
    });
    this.formbanner.valueChanges.subscribe(value=>console.log('value',value));
  }

  fileProgress(fileInput: any, tipo) {
    this.fileData = <File>fileInput.target.files[0];
    this.preview(tipo);
  }

  preview(tipo) {
    // Show preview 
    var mimeType = this.fileData.type;
    if (mimeType.match(/image\/*/) == null) {
      return;
    }

    var reader = new FileReader();
    reader.readAsDataURL(this.fileData);
    reader.onload = (_event) => {
    
        this.formbanner.controls[tipo].setValue(reader.result);

        this.banner = reader.result
      
    }
  }

  uploadFile(event, tipo) {

    var file = (event.target as HTMLInputElement).files[0];
    let extension = file.name.split('.')[file.name.split('.').length - 1];

    // File Preview
    const reader = new FileReader();
    reader.onload = () => {
      //this.preview = reader.result as string;
      this.formbanner.controls[tipo].setValue(reader.result);
      this.subirImagen(tipo, extension, file);
  

    }
    reader.readAsDataURL(file)
  }


  async subirImagen(tipo, extension, imagen) {
    console.log('tipo', tipo);
    let respuesta = await this.catalogoService.uploadImage(tipo, extension, imagen);
    console.log('respuesta',respuesta);
    this.formbanner.controls[tipo].setValue(respuesta.url)
    //tipo == 'portadaImg' ? this.formPortada.controls['urlPortada'].setValue(respuesta.url) : this.formPortada.controls['urlContraPortada'].setValue(respuesta.url);

  }


  onSubmit() {
    const formData = new FormData();
    formData.append('file', this.fileData);
    console.log('formData', formData);
  }

  async guardarAtributos() {

     let objeto: any = await this.localS.get('catalogo');
    let values = this.formbanner.value;
    objeto.banner = await values;
    await this.localS.remove('catalogo');
    await this.localS.set('catalogo', objeto);
    console.log('catalogo',objeto);
  }

  cargarDatos(objeto: any) {
    this.productosObtenidos = objeto.prodObtenidos;
    this.productosObtenidos.map(arreglo => {
      this.formbanner.setControl(arreglo.linea, new FormControl(null, [Validators.required]));
    }
    ); 
  }

}
