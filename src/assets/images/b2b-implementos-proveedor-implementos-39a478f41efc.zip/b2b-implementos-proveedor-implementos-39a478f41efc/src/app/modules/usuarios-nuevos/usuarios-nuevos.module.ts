import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UsuariosNuevosRoutingModule } from './usuarios-nuevos-routing.module';
import { PageUsuariosNuevosComponent } from './pages/page-usuarios-nuevos/page-usuarios-nuevos.component';
import { SharedModule } from 'src/app/shared/shared.module';


@NgModule({
  declarations: [PageUsuariosNuevosComponent],
  imports: [
    CommonModule,
    UsuariosNuevosRoutingModule,
    SharedModule
  ]
})
export class UsuariosNuevosModule { }
