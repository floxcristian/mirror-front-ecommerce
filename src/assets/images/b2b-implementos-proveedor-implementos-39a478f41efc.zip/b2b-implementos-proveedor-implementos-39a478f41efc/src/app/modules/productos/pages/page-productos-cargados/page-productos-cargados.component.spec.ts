import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PageProductosCargadosComponent } from './page-productos-cargados.component';

describe('PageProductosCargadosComponent', () => {
  let component: PageProductosCargadosComponent;
  let fixture: ComponentFixture<PageProductosCargadosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PageProductosCargadosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PageProductosCargadosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
