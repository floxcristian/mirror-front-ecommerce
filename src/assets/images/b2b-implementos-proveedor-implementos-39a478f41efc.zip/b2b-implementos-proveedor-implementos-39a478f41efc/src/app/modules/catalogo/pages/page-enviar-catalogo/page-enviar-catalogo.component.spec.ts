import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PageEnviarCatalogoComponent } from './page-enviar-catalogo.component';

describe('PageEnviarCatalogoComponent', () => {
  let component: PageEnviarCatalogoComponent;
  let fixture: ComponentFixture<PageEnviarCatalogoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PageEnviarCatalogoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PageEnviarCatalogoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
