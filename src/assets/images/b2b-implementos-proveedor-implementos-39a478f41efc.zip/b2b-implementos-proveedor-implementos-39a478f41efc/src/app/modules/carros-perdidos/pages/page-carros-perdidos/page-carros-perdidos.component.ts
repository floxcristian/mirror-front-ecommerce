import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { CarroService } from '../../../../shared/services/carro.service';
import {pluck, tap} from 'rxjs/operators'
import { Carro } from '../../../../shared/models/carro.model';
import { UsuarioService } from '../../../../shared/services/usuario.service';
import { InfoCarros, DataCarro } from '../../../../shared/models/carro-perdido.model';
import * as moment from 'moment';
import { InfoAnalytics } from '../../../../shared/models/info-analytics.model';
import { DataAnalytics } from '../../../../shared/models/analytics.model';
import { NgbDate} from '@ng-bootstrap/ng-bootstrap';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';


@Component({
  selector: 'app-carros-perdidos',
  templateUrl: './page-carros-perdidos.component.html',
  styleUrls: ['./page-carros-perdidos.component.scss']
})
export class PageCarrosPerdidosComponent implements OnInit {
  chartData:any
  infoAnalytics:InfoAnalytics;
  infoCarros:DataCarro;
  detalleCarro:Carro;
  carrosTotales:Carro[]=[];
  carrosRegistrados:Carro[]=[];
  carrosAnonimos:Carro[]=[];
  carrosInvitados:Carro[]=[];
  todosFlag = true;
  maxDate = new Date();
  usuario:any;
  modalState = false
  fechaInicio: NgbDate;
  fechaTermino: NgbDate;
  archivo:string;
  todosLosProductos:any[]=[]
  arregloDeArreglos:any[] =[]
  detalleProductos:any[]=[];
  loading:boolean
  anchoPantalla;
  ranking:any;
  infoRanking:any;

  @ViewChild('modalRanking') modalRanking: TemplateRef<any>;
  modalRankingRef: BsModalRef;

  fechas = {
    inicio: moment().startOf('day').toISOString().slice(0, moment().startOf('day').toISOString().indexOf('T')),
    termino: moment().endOf('day').toISOString().slice(0, moment().startOf('day').toISOString().indexOf('T'))
  };

  mes = {
    "inicio": moment().startOf('month').toISOString().slice(0, moment().startOf('month').toISOString().indexOf('T')),
    "termino": moment().endOf('day').toISOString().slice(0, moment().startOf('day').toISOString().indexOf('T'))
  }

  tableState = {
    todos:false,
    registrados:false,
    anonimos:false,
    invitados:false
  };
  totalVisitas:number;
  arregloDias:number[] = [];
  arregloVisitas:number[] = [];

  dataCarrosPerdidosMes = {
    dia:[],
    cantidad:[]
  }

  graficoVisitas = {
    name:'Visitas',
    data: this.arregloVisitas
  }
  graficoCP = {
    name:'Carros Perdidos',
    data:this.dataCarrosPerdidosMes.cantidad
  }

  arregloProductosPerdidos:any[]=[]

  constructor(
    private carroService:CarroService,
    private usuarioService:UsuarioService,
    private modalService:BsModalService
) {
  this.archivo = "DetalleCarrosPerdidos_" + new Date().toISOString() + ".xlsx";
  this.anchoPantalla = screen.width;
  this.chartData = this.dataGraficoCP

 }


 ngOnInit(): void {
  this.loading = true
    this.carroService.getCarros(this.fechas).pipe(
    tap((data:InfoCarros) => {
      this.infoCarros = data.data
      for(let i in this.infoCarros.detalleMes){
        this.dataCarrosPerdidosMes.cantidad.push(this.infoCarros.detalleMes[i]['cantidad'])  
      }
      for(let i in this.infoCarros.carros){
        for(let j in this.infoCarros.carros[i].productosDetalle){
          this.arregloProductosPerdidos.push(this.infoCarros.carros[i].productosDetalle[j]['sku'])
        }
      }
      }),
    pluck('data','carros'),
    tap( () => {
      for(let i in this.infoCarros.carros){
        switch(this.infoCarros.carros[i].tipoCliente){
          case "Registrado": this.carrosRegistrados.push(this.infoCarros.carros[i])
          break;
          case "Anonimo": this.carrosAnonimos.push(this.infoCarros.carros[i])
          break;
          case "Invitado": this.carrosInvitados.push(this.infoCarros.carros[i])
          break;
        } 
      }
    }),
    tap( (data:Carro[]) => {
      for(let i in this.infoCarros.carros){
        if(this.infoCarros.carros[i].productosDetalle != []) {
          for(let j in data[i].productosDetalle){
            this.infoCarros.carros[i].productosDetalle[j] = {...this.infoCarros.carros[i].productosDetalle[j] , id:this.infoCarros.carros[i].id, usuario:this.infoCarros.carros[i].usuario}
          }  
        }
      }
    
    for(let k in this.infoCarros.carros){
      this.arregloDeArreglos = this.arregloDeArreglos.concat(this.infoCarros.carros[k].productosDetalle) 
    }
    })
  ).subscribe(() => {
    this.carrosTotales = this.infoCarros.carros 
    this.loading = false

  })

  this.carroService.getAnalytics(this.mes).pipe(
    tap((data:DataAnalytics) => {
      this.totalVisitas = data.totales["Pagina Inicio"]
      for(let i in data.detalle){
        this.arregloDias.push(Number.parseInt(i.slice(-2)))
        for(let j in data.detalle[i]){
          if(data.detalle[i][j].tipo == 'Pagina Inicio' )
          this.arregloVisitas.push(data.detalle[i][j].cantidad)
        }
      }
    })
  ).subscribe(  () => this.ranking = this.contadorDeProductos());
}
filtrarFechas(){
  this.loading = true
  this.carrosRegistrados = [];
  this.carrosAnonimos = [];
  this.carrosInvitados = [];
  let fechaInicio =  new Date(this.fechaInicio.year, this.fechaInicio.month - 1, this.fechaInicio.day).toISOString();
  let fechaTermino =  new Date(this.fechaTermino.year, this.fechaTermino.month - 1, this.fechaTermino.day).toISOString();
   this.fechas = {
    inicio: moment(fechaInicio).startOf('day').toISOString(),
    termino: moment(fechaTermino).endOf('day').toISOString() 
  }
this.carroService.filtrarFechas(this.fechas).pipe(
  tap((data: InfoCarros) => {
    this.infoCarros = data.data
    for(let i in this.infoCarros.carros){
      for(let j in this.infoCarros.carros[i].productosDetalle){
        this.arregloProductosPerdidos.push(this.infoCarros.carros[i].productosDetalle[j]['sku'])
      }
    }
  }),
  tap( () => {
    this.carrosTotales = this.infoCarros.carros 
    for(let i in this.infoCarros.carros){
      switch(this.infoCarros.carros[i].tipoCliente){
        case "Registrado": this.carrosRegistrados.push(this.infoCarros.carros[i])
        break;
        case "Anonimo": this.carrosAnonimos.push(this.infoCarros.carros[i])
        break;
        case "Invitado": this.carrosInvitados.push(this.infoCarros.carros[i])
        break;
      } 
    }
  })
  ).subscribe( () => {this.ranking = this.contadorDeProductos(); this.loading = false
  })

}

/**Despliegue de detalle de carros perdidos de acuerdo a tipo de cliente
* Cuando se muestra uno lso otros se cierran
*/
toggleTable(tipo:string){
  switch(tipo){
    case "todos":
      this.tableState.registrados = false
      this.tableState.anonimos = false
      this.tableState.invitados = false
      this.tableState.todos = !this.tableState.todos;
      break;
    case "anonimos":
      this.tableState.registrados = false
      this.tableState.todos = false
      this.tableState.invitados = false
      this.tableState.anonimos = !this.tableState.anonimos;
      break;
    case "invitados":
      this.tableState.registrados = false
      this.tableState.todos = false
      this.tableState.anonimos = false
      this.tableState.invitados = !this.tableState.invitados;
      break;
    case "registrados":
      this.tableState.anonimos = false
      this.tableState.todos = false
      this.tableState.invitados = false
      this.tableState.registrados = !this.tableState.registrados;
      break;
  
  }
}

async getTodosLosCarros(){
   return  this.carrosTotales
}


getVisitas(){
  return this.arregloVisitas
}

getCantidadCarrosPerdidosGrafico(){
  return this.dataCarrosPerdidosMes.cantidad
}

contadorDeProductos(){
  this.loading = true
  let arregloSinDuplicados = this.arregloProductosPerdidos
  arregloSinDuplicados = this.arregloProductosPerdidos
    .reduce((newTempArr, el) => (newTempArr.includes(el) ? newTempArr : [...newTempArr, el]), [])
  var contadorProductos = {};
  let arregloDeConteos:any[] = [];


  this.arregloProductosPerdidos.forEach(function(producto) {
    if (!contadorProductos.hasOwnProperty(producto)) {
    contadorProductos[producto] = 0
    }
      contadorProductos[producto] += 1;
      });
    for(let i in arregloSinDuplicados){
       // console.log( (contadorProductos[arregloSinDuplicados[i]]) + " veces el producto:" + arregloSinDuplicados[i])
       arregloDeConteos.push({
         producto:arregloSinDuplicados[i],
         conteo:contadorProductos[arregloSinDuplicados[i]]
        })
    }

  this.infoRanking = arregloDeConteos
  let primerLugar:any;
  let segundoLugar:any;
  let tercerLugar:any;

  for (let j = 0; j < 3; j++) {

    let numerosConteo:number[]=[];
    let prodPrimerLugar:any
    let max:number
    for(let i in arregloDeConteos){
      numerosConteo.push(arregloDeConteos[i].conteo)
    }
    max = Math.max(...numerosConteo)
    prodPrimerLugar = arregloDeConteos.find(elemento => elemento.conteo == max  );
    switch(j){
      case 0: primerLugar = prodPrimerLugar;
      break;
      case 1: segundoLugar = prodPrimerLugar;
      break;
      case 2: tercerLugar = prodPrimerLugar;
      break;
    }
    arregloDeConteos  = arregloDeConteos.filter( i => { return i.producto != prodPrimerLugar.producto})
  }
  this.loading = false

  return {
    primerMasAgregado:primerLugar,
    segundoMasAgregado:segundoLugar,
    tercerMasAgregado:tercerLugar
  }
}

dataGraficoCP = {
  chart: {
    height: 350,
    type: 'area',
    background:'light',
  },
  dataLabels: {
    enabled: false
  },
  stroke: {
    curve: 'smooth'
  },
  colors: ['#ffa21d', '#ff5252'],
  series: [
    this.graficoVisitas,
    this.graficoCP
   ],

  xaxis: {
      type:'numeric',
      hideOverlappingLabels:true,

    },
  tooltip: {

  }
};

listaCompleta(infoRanking){
  this.infoRanking = infoRanking
  this.modalRankingRef = this.modalService.show(this.modalRanking);
}

}