import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PageUsuariosNuevosComponent } from './page-usuarios-nuevos.component';

describe('PageUsuariosNuevosComponent', () => {
  let component: PageUsuariosNuevosComponent;
  let fixture: ComponentFixture<PageUsuariosNuevosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PageUsuariosNuevosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PageUsuariosNuevosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
