import { Component, OnInit, Input } from '@angular/core';
import { CarroService } from '../../../../shared/services/carro.service';
import {tap, map} from 'rxjs/operators'
import { DataAnalytics } from '../../../../shared/models/analytics.model';
import {InfoCarros, DataCarro } from '../../../../shared/models/carro-perdido.model';
import { InfoVenta, DataInfoVenta } from '../../../../shared/models/info-ventas.model';
import * as moment from 'moment';
import { PageResumenComponent } from 'src/app/modules/resumen/pages/page-resumen/page-resumen.component';
import { NgbDate } from '@ng-bootstrap/ng-bootstrap';


@Component({
  selector: 'app-icons',
  templateUrl: './page-funnel.component.html',
  styleUrls: ['./page-funnel.component.scss'],
  providers:[PageResumenComponent]
})
export class PageFunnelComponent implements OnInit {
  fechaInicio:NgbDate;
  fechaTermino:NgbDate;
  maxDate = new Date();
  detalleToggle = true;
  mobileFlag = true
  searchClicked = false;

  modelTotal:any;
  modelResumen:any;
  modelB2C:any

  chartStyleGrande:any;
  chartStyleChico:any;

  totalVisitas:number;
  totalMetodoEnvio:number = 0;
  loading:boolean

  @Input()
  infoVentas:DataInfoVenta;
  @Input()
  infoCarrosPerdidos:DataCarro;

  hoy = {
    inicio: moment().startOf('day').toISOString().slice(0, moment().startOf('day').toISOString().indexOf('T')),
    termino: moment().endOf('day').toISOString().slice(0, moment().endOf('day').toISOString().indexOf('T'))
  }
  mes = {
    "inicio": moment().startOf('month').toISOString().slice(0, moment().startOf('month').toISOString().indexOf('T')),
    "termino": moment().endOf('day').toISOString().slice(0, moment().startOf('day').toISOString().indexOf('T'))
  }
  fechas = {
    inicio: moment().startOf('day').toISOString(),
    termino: moment().endOf('day').toISOString()
  }
  fechasMes = {
    inicio: moment().startOf('month').toISOString(),
    termino: moment().endOf('day').toISOString()
  }
  
  constructor(
    private carroService:CarroService,
    ) {
  }

  verDetalle(){
    this.detalleToggle = !this.detalleToggle
  }

  porcentaje(item){
    let total = ((item*100)/this.totalVisitas).toFixed(2) + "%"
    return total
  }


    ngOnInit() {
    this.loading = true;
    
    
    this.carroService.estadisticasFecha(this.fechas)
    .subscribe( (data:InfoVenta) => this.infoVentas = data.data)
     

    this.carroService.getAnalytics(this.mes).pipe(
      tap( (data:DataAnalytics) => {
        this.totalVisitas = data.totales["Pagina Inicio"]

        

        if(data.totales["Método de envió"]){
          this.totalMetodoEnvio = Number(data.totales["Método de envió"]) + Number(data.totales["Método de envío"])
        }else{
        this.totalMetodoEnvio =Number(data.totales["Método de envío"])
        }


        this.modelResumen = [{
          stat: 'Visitas',
          count: this.totalVisitas + "  100%",
          color: '#B22222'
        }, {
          stat: 'Shopping',
          count:  data.totales.Shopping +"  -  "+  this.porcentaje(data.totales.Shopping),
          color: '#808080'
        }, {
          stat: 'Comprobante de Compra',
          count: this.infoVentas.detalleMes.cantidadVentas +" -   "+  this.porcentaje(this.infoVentas.detalleMes.cantidadVentas),
          color: '#008B8B'
        }]
        this.modelTotal = [{
          stat: 'Visitas',
          count: this.totalVisitas + " -  100%",
          color: '#B22222'
        }, {
          stat: 'Shopping',
          count: data.totales.Shopping +" -   "+  this.porcentaje(data.totales.Shopping),
          color: '#808080'
        }, {
          stat: 'Ficha Producto',
          count: data.totales["Ficha SKU"]+" -   "+  this.porcentaje(data.totales['Ficha SKU']),
          color: '#3CB371'
        },
        , {
          stat: 'Agregar al Carro',
          count: data.totales["Agregar producto al carro"]+" -  "+  this.porcentaje(data.totales['Agregar producto al carro']),
          color: '#48D1CC'
        }
        , {
          stat: 'Ver resumen del Carro',
          count: data.totales["Resumen carro"]+" -   "+  this.porcentaje(data.totales['Resumen carro']),
          color: '#CD5C5C'
        }
        , {  
          stat: 'Método de envío',
          count: this.totalMetodoEnvio +" -   "+  this.porcentaje(this.totalMetodoEnvio),
          color: '#E9967A'
        }
        , {
          stat: 'Forma de Pago',
          count: data.totales["Metodo de pago"]+" -   "+  this.porcentaje(data.totales['Metodo de pago']),
          color: '#2185b4'
        }
        , {
          stat: 'Ventas totales',
          count: this.infoVentas.detalleMes.cantidadVentas +" -   "+  this.porcentaje(this.infoVentas.detalleMes.cantidadVentas),
          color: '#008B8B'  
        }]
        this.loading = false;
      }
      )
    ).subscribe();
    

   //this.carroService.filtrarFechas(this.fechasMes).pipe(
     //map((data:InfoCarros) => this.infoCarrosPerdidos = data.data)).subscribe( )
    
  }


  filtrarFechas(){
    this.loading = true
    this.searchClicked = true;

    
    let fechas = {
      inicio: moment(new Date(this.fechaInicio.year, this.fechaInicio.month - 1, this.fechaInicio.day)).startOf('day').toISOString().slice(0, moment().startOf('day').toISOString().indexOf('T')),
      termino: moment(new Date(this.fechaTermino.year, this.fechaTermino.month - 1, this.fechaTermino.day)).endOf('day').subtract(1,"days").toISOString().slice(0, moment().endOf('day').toISOString().indexOf('T')) 
    }
    let fechasVentas = {
      inicio: moment(new Date(this.fechaInicio.year, this.fechaInicio.month - 1, this.fechaInicio.day)).startOf('day').toISOString(),
      termino: moment(new Date(this.fechaTermino.year, this.fechaTermino.month - 1, this.fechaTermino.day)).endOf('day').toISOString() 
    }


    this.carroService.estadisticasFecha(fechasVentas).pipe(
      map((data:InfoVenta) => this.infoVentas = data.data)).subscribe()


      
    this.carroService.getAnalytics(fechas).pipe(
      tap( (data:DataAnalytics) => {
        this.totalVisitas = data.totales["Pagina Inicio"]

        

        if(data.totales["Método de envió"]){
          this.totalMetodoEnvio = Number(data.totales["Método de envió"]) + Number(data.totales["Método de envío"])
        }else{
        this.totalMetodoEnvio =Number(data.totales["Método de envío"])
       }
        this.totalVisitas = data.totales["Pagina Inicio"]
        this.modelResumen = [{
          stat: 'Visitas',
          count: this.totalVisitas + "  100%",
          color: '#B22222'
        }, {
          stat: 'Shopping',
          count:  data.totales.Shopping +"  -  "+  this.porcentaje(data.totales.Shopping),
          color: '#808080'
        }, {
          stat: 'Comprobante de Compra',
          count: this.infoVentas.cantidad +" -   "+  this.porcentaje(this.infoVentas.cantidad),
          color: '#008B8B'
        }]



        this.modelTotal = [{
          stat: 'Visitas',
          count: this.totalVisitas + " -  100%",
          color: '#B22222'
        }, {
          stat: 'Shopping',
          count: data.totales.Shopping +" -   "+  this.porcentaje(data.totales.Shopping),
          color: '#808080'
        }, {
          stat: 'Ficha Producto',
          count: data.totales["Ficha SKU"]+" -   "+  this.porcentaje(data.totales['Ficha SKU']),
          color: '#3CB371'
        },
        , {
          stat: 'Agregar al Carro',
          count: data.totales["Agregar producto al carro"]+" -  "+  this.porcentaje(data.totales['Agregar producto al carro']),
          color: '#48D1CC'
        }
        , {
          stat: 'Ver resumen del Carro',
          count: data.totales["Resumen carro"]+" -   "+  this.porcentaje(data.totales['Resumen carro']),
          color: '#CD5C5C'
        }
        , {  
          stat: 'Método de envío',
          count: this.totalMetodoEnvio +" -   "+  this.porcentaje(this.totalMetodoEnvio),
          color: '#E9967A'
        }
        , {
          stat: 'Forma de Pago',
          count: data.totales["Metodo de pago"]+" -   "+  this.porcentaje(data.totales['Metodo de pago']),
          color: '#2185b4'
        }
        , {
          stat: 'Ventas totales',
          count: this.infoVentas.cantidad +" -   "+  this.porcentaje(this.infoVentas.cantidad),
          color: '#008B8B'  
        }]
        this.loading = false;
      }
      )
    ).subscribe();

  }

}
