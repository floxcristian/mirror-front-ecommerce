import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PageProductosLineasComponent } from './pages/page-productos-lineas/page-productos-lineas.component';
import { PageProductosBannerComponent } from './pages/page-productos-banner/page-productos-banner.component';
import { PageProductosCargadosComponent } from './pages/page-productos-cargados/page-productos-cargados.component';



const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    redirectTo: 'cargar-lineas-productos'
  },
  {
    path: 'cargar-lineas-productos',
    component:PageProductosLineasComponent
  },
  {
    path: 'productos-cargados',
    component:PageProductosCargadosComponent
  },
  {
    path: 'cargar-banner',
    component:PageProductosBannerComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProductosRoutingModule { }
