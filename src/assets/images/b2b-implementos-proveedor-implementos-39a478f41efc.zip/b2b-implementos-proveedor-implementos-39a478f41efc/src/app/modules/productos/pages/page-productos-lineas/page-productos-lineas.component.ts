import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Clacom } from 'src/app/shared/interfaces/clacom';
import { Person, CatalogoService } from 'src/app/shared/services/catalogoService/catalogo.service';
import { ToastrService } from 'ngx-toastr';
import { LocalStorageService } from 'angular-2-local-storage';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-page-productos-lineas',
  templateUrl: './page-productos-lineas.component.html',
  styleUrls: ['./page-productos-lineas.component.scss']
})
export class PageProductosLineasComponent implements OnInit {

  preview: boolean = false;
  previewprod: boolean = false;
  previewfotos: boolean = false;
  productoForm: FormGroup;
  formConfiguracion: FormGroup;
  clacomO: Clacom;
  selectProducto: Array<any> = [];
  clacom: Array<any> = [];
  uens: Array<any> = [];
  categorias: Array<any> = [];
  lineas: Array<any> = [];
  people: Person[] = [];
  productosObtenidos: Array<any> = [];
  selectedPeople = [];
  template:any;
  cantAtrib: number =0;
  constructor(private fb: FormBuilder, private catalogoService: CatalogoService, private toast: ToastrService,private localS: LocalStorageService) {
    this.selectProducto = environment.selectProductos;
    let objeto : any = localS.get('catalogo');
    this.cargarDatos(objeto);
    this.productoForm = this.fb.group({
      /*  jerarquia: new FormControl([],Validators.required), */
      uenSelec: new FormControl([]),
      categorias: new FormControl([]),
      lineas: new FormControl([]),
      /*   atributos: new FormControl([],Validators.required)  */

    });
    this.formConfiguracion = this.fb.group({


    })
    this.clacomO = new Clacom();
  }

  async ngOnInit() {
    this.clacom = await this.catalogoService.obtenerUenCategoriaProductos();
    this.cargarSelect();
 
    this.productoForm.valueChanges.subscribe(value => {

      this.filtrarSelect(value, 'uenSelec', 'categorias');
      
      console.log('valueChanges',value);
    });

    this.formConfiguracion.statusChanges.subscribe(status=>{
     
      if(status=='VALID'){
        this.guardarAtributos();
        this.preview=true;
      }else{
        this.preview=false;
      }
   
    })
  }

  async obtenerProductos() {
    let form = this.productoForm.value;
    if (form.uenSelec.length == 0 && form.categorias.length == 0 && form.lineas.length == 0) {
      this.toast.error('Debe seleccionar un elemento minimo');
      return
    }

    let objeto = {
      uen: [],
      categorias: [],
      lineas: [],
    }

    objeto.uen = this.obtenerNombre(form.uenSelec, 'uens');
    objeto.categorias = this.obtenerNombre(form.categorias, 'categorias');
    objeto.lineas = this.obtenerNombre(form.lineas, 'lineas');
 
    let respuesta = await this.catalogoService.obtenerProductos(objeto);
   
    console.log('form',form);
    console.log('objeto',objeto);
    let arrCategorias =[]
    
    if(form.categorias.length>0){
      let categoria =objeto.categorias
      let arr =[];
      categoria.map(categ=>{
        let categoriaObj ={
          categoria:categ,
          linea:categ,
          filtros:[],
          productos:[],
          cantidadAtributos:0
        }

       
        let filtroCat = respuesta.filter(resp=>resp.categoria == categ.toUpperCase());
        filtroCat.map(cat=>{
          cat.filtros.map(campos =>{
            let objeto ={
              atrib:'Atributos',
              nombre:campos,
            }
            let existe = arr.filter(obj=>obj.nombre==campos);
            if(existe.length==0){
              arr.push(objeto);
              categoriaObj.filtros.push(campos);
            }
            

          } );
          cat.productos.map(prd=>categoriaObj.productos.push(prd))
        })
        categoriaObj.cantidadAtributos = categoriaObj.filtros.length;
        arrCategorias.push(categoriaObj)
        this.formConfiguracion.setControl(categ, new FormControl(categoriaObj.filtros, [Validators.required,Validators.maxLength(this.cantAtrib)]));

      })
      console.log('arrCategorias',arrCategorias);

      /* respuesta.map(arreglo => {
      
   
        arreglo.cantidadAtributos = arreglo.filtros.length;
        
        arreglo.filtros.map(campos =>{
          let objeto ={
            atrib:'Atributos',
            nombre:campos,
          }
          arr.push(objeto)
        } );
        this.formConfiguracion.setControl(arreglo.linea, new FormControl(arreglo.filtros, [Validators.required,Validators.maxLength(this.cantAtrib)]));
  
        
      }
      );
      respuesta.atributos =arr; */
      this.productosObtenidos =arrCategorias;
      console.log('formConfiguracion',this.formConfiguracion);
    }
    /* respuesta.map(arreglo => {
      
   
      arreglo.cantidadAtributos = arreglo.filtros.length;
      let arr =[];
      arreglo.filtros.map(campos =>{
        let objeto ={
          atrib:'Atributos',
          nombre:campos,
        }
        arr.push(objeto)
      } );
      this.formConfiguracion.setControl(arreglo.linea, new FormControl(arreglo.filtros, [Validators.required,Validators.maxLength(this.cantAtrib)]));

      arreglo.atributos =arr;
    }
    ); */

    //this.productosObtenidos = respuesta;
  }

  obtenerCategoria($event) {
    this.productoForm.value
  }

  cargarSelect() {
    this.clacom.map(uen => {
      uen.categorias.map(cate => {

        cate.linea.map(line => {
          let objetoLinea = {
            codigoPadre: cate.codigo,
            nombrePadre: cate.nombre,
            codigo: line.codigo,
            nombre: line.linea
          };
          this.lineas.push(objetoLinea);
          this.clacomO.lineas.push(objetoLinea)

        })
        let objetoCate = {
          codigoPadre: uen.codigo,
          nombrePadre: uen.nombre,
          codigo: cate.codigo,
          nombre: cate.categoria
        };
        this.categorias.push(objetoCate);
        this.clacomO.categorias.push(objetoCate);
      })
      let ojetoUen = {
        codigo: uen.codigo,
        nombre: uen.uen
      };
      this.uens.push(ojetoUen);
      this.clacomO.uens.push(ojetoUen);
    });

  };

  filtrarSelect(value, tipo, lista) {
    if (value[tipo].length > 0) {

      let uens = value[tipo];

      let lst = [];
      uens.map(uen => {

        let filtro = this.clacomO[lista].filter(cate => cate.codigoPadre == uen);

        if (filtro.length > 0) {
          filtro.map(ft => lst.push(ft));
        }

      })

      lst.length > 0 ? this[lista] = lst : null;



    } else if (value[tipo].length == 0) {

      this[lista] = this.clacomO[lista];
    }
  }

  obtenerNombre(lista, busqueda) {
    let array = [];
    lista.map(uen => {
      let exite = this.clacomO[busqueda].filter(bs => bs.codigo == uen);

      if (exite.length > 0) {
        exite.map(ft => array.push(ft.nombre));
      }
    });
    return array;
  }

  generarListadoProductos(filtro, respuesta) {
    let arr = [];
    let arrG = [];
    let objeto: any = {}
    let aux = respuesta;
   

    filtro.lineas.map(producto => {
      let prod = aux.filter(prod => producto == prod.linea);
      if (prod.length > 0) {
        objeto = {};
        objeto.uen = prod[0].uen;
        objeto.categoria = prod[0].categoria;
        objeto.linea = prod[0].linea;
        objeto.productos = prod;
      }
      arrG.push(objeto);
    });
  
    this.productosObtenidos = arrG;
  }

  
  cargarDatos(objeto: any) {
    if(objeto.atributos){
      this.cantAtrib =objeto.atributos
    }
    this.template = objeto.template;
  }
  async guardarAtributos() {

    let objeto: any = await this.localS.get('catalogo');
    let product = this.productoForm.value;
    let config = this.formConfiguracion.value;
 
    this.productosObtenidos.map(prod=>{

      let filtro = prod.productos.filter(prd=>prd.imagen==true);
      prod.productos= filtro
  
    }) 
    objeto.clacom =product;
    objeto.productosAtributos = config;
    objeto.prodObtenidos = this.productosObtenidos;
    await this.localS.remove('catalogo');
    await this.localS.set('catalogo', objeto);
    console.log('guardo', objeto);
  }
}
