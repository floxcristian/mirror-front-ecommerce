import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProductosRoutingModule } from './productos-routing.module';

import { SharedModule } from 'src/app/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { PageProductosLineasComponent } from './pages/page-productos-lineas/page-productos-lineas.component';
import { PageProductosBannerComponent } from './pages/page-productos-banner/page-productos-banner.component';
import { PageProductosCargadosComponent } from './pages/page-productos-cargados/page-productos-cargados.component';


@NgModule({
  declarations: [
    PageProductosLineasComponent,
    PageProductosBannerComponent,
    PageProductosCargadosComponent
  ],
  imports: [
    CommonModule,
    ProductosRoutingModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    NgSelectModule,
  ]
})
export class ProductosModule { }
