import { Component, OnInit, Input, EventEmitter, Output, Directive, ViewChildren, QueryList, ViewChild, TemplateRef } from '@angular/core';
import { NgbModal, NgbPaginationConfig } from '@ng-bootstrap/ng-bootstrap';
import { UiModalComponent } from 'src/app/shared/components/modal/ui-modal/ui-modal.component';

import { UsuarioService } from '../../../../shared/services/usuario.service';
import { map } from 'rxjs/operators';
import { Carro } from '../../../../shared/models/carro.model';
import { ModalModule } from 'src/app/shared/components';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';

export type SortColumn = keyof Carro | '';
export type SortDirection = 'asc' | 'desc' | '';
const rotate: {[key: string]: SortDirection} = { 'asc': 'desc', 'desc': '', '': 'asc' };
const compare = (v1: number, v2: number) => v1 < v2 ? -1 : v1 > v2 ? 1 : 0;

export interface SortEvent {
  column: SortColumn;
  direction: SortDirection;
}

@Directive({
  selector: 'th[sortable]',
  host: {
    '[class.asc]': 'direction === "asc"',
    '[class.desc]': 'direction === "desc"',
    '(click)': 'rotate()'
  }
})
export class NgbdSortableHeader {
  @Input() sortable: SortColumn = '';
  @Input() direction: SortDirection = '';
  @Output() sort = new EventEmitter<SortEvent>();

  rotate() {
    this.direction = rotate[this.direction];
    this.sort.emit({column: this.sortable, direction: this.direction});
  }
}


@Component({
  selector: 'app-tabla-carros-perdidos',
  templateUrl: './tabla-carros-perdidos.component.html',
  styleUrls: ['./tabla-carros-perdidos.component.scss']
})
export class TablaCarrosPerdidosComponent implements OnInit {
  @Input()
  carroTipo:Carro[] = []
  @Input()
  detalleCarro:any
  modalState = false
  fechaInicio: Date;
  fechaTermino: Date;
  @Input()  
  todosFlag:boolean;
  loading:boolean
  usuario:any;
  totalItems: number;
  page: number = 1;
  pageSize:number = 10;
  countries = this.carroTipo

  @ViewChild('modalCarro') modalCarro: TemplateRef<any>;
  modalCarroRef: BsModalRef;

  @ViewChild('modalUsuario') modalUsuario: TemplateRef<any>;
  modalUsuarioRef: BsModalRef;

  idCarro:any





  @ViewChildren(NgbdSortableHeader) headers: QueryList<NgbdSortableHeader>;
    onSort({column, direction}: SortEvent) {



    this.headers.forEach(header => {
      if (header.sortable !== column) {
        header.direction = '';
      }
    });
      
    if (direction === '' || column === '') {
      this.countries = this.carroTipo;
    } else {
      this.carroTipo = [...this.carroTipo].sort((a, b) => {
        const res = compare(Number(a[column]),Number(b[column]));

        return direction === 'asc' ? res : -res;
      });
    }
  }


 


 

  constructor(
    private usuarioService:UsuarioService,
    private modalService:BsModalService
    ) {
     }

  ngOnInit(): void {
    for (let i = 0; i < this.carroTipo.length; i++) {
      this.carroTipo[i] = {...this.carroTipo[i], hash:i+1}
    }
  }
  


  open(idCarro) {
    for (let i = 0; i < this.carroTipo.length; i++) {
      if(this.carroTipo[i].id== idCarro){
        this.detalleCarro = this.carroTipo[i]
      } 
     }
    this.modalCarroRef = this.modalService.show(this.modalCarro);
  }
  
  verUsuario(usuario){
    this.usuarioService.getUsuarioByUser(usuario).pipe(
      map( (data:any) => {this.usuario = data.data

        this.modalUsuarioRef = this.modalService.show(this.modalUsuario);


      })
    ).subscribe() 
  }



}
