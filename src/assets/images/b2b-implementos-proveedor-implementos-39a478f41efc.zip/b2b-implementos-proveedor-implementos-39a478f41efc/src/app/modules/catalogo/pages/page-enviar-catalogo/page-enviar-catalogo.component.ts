import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-enviar-catalogo',
  templateUrl: './page-enviar-catalogo.component.html',
  styleUrls: ['./page-enviar-catalogo.component.scss']
})
export class PageEnviarCatalogoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
