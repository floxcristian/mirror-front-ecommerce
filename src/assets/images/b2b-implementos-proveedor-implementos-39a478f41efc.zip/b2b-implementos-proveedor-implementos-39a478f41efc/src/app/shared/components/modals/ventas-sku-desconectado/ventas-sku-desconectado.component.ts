import { Component, OnInit, Input } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { ArticulosService } from 'src/app/shared/services/articulos/articulos.service';
@Component({
  selector: 'app-ventas-sku-desconectado',
  templateUrl: './ventas-sku-desconectado.component.html',
  styleUrls: ['./ventas-sku-desconectado.component.scss']
})
export class VentasSkuDesconectadoComponent implements OnInit {
  lstVentas: Array<any>[] =[];
  @Input()skuVentas:any;
  @Input()modalVentasRef:BsModalRef;
    constructor(private articuloService: ArticulosService) { }

  ngOnInit(): void {
    console.log('entré el modalventas yeahh');
   console.log(this.skuVentas);
   this.verVentasSku();
  }
  async actualizarDocumentoVenta(){
    //bla bla bla
  }
  
  async verVentasSku() {
    this.lstVentas = null;
    let lstVendidos = await this.articuloService.obtenerVentasSku(this.skuVentas);
    console.log('lstVendidos',lstVendidos);
    if(lstVendidos.length ==0){
      this.lstVentas= [];
      return
    }
    this.lstVentas = lstVendidos[0].vendidos;
    console.log("lstVendidos",lstVendidos);
    console.log("lstVendidos.vendidos",lstVendidos[0].vendidos);
    console.log("this.lstVentas",this.lstVentas);
  }
}
