import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AutenticacionService } from '../services/autenticacionService/autenticacion.service';

@Injectable({
  providedIn: 'root'
})
export class AutenticacionGuard implements CanActivate {

  constructor(private autenticacionService: AutenticacionService,private router: Router) { }
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {

    const currentUser = this.autenticacionService.currentUserValue;
    console.log('currentUser',currentUser);
    if (currentUser) {
      // authorised so return true
      //this.router.navigate(['/autenticacion']);
      console.log('entree');
      return true;
    }

    // not logged in so redirect to login page with the return url
    this.router.navigate(['/autenticacion']);
    return false;
  }


}

