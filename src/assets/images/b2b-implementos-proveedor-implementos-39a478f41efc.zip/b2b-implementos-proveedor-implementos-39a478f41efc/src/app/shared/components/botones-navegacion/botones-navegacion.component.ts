import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-botones-navegacion',
  templateUrl: './botones-navegacion.component.html',
  styleUrls: ['./botones-navegacion.component.scss']
})
export class BotonesNavegacionComponent implements OnInit {
  @Input() volver : string; 
  @Input() continuar : string; 
  @Input() disabled : boolean; 
  constructor() { }

  ngOnInit(): void {
  }

}
