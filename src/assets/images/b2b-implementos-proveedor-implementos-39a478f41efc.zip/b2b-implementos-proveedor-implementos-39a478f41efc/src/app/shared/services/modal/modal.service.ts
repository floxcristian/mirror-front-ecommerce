import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ModalService {
  vendedor: any;


  constructor() { }

  enviarVendor(vendedor){
    
    return this.vendedor =vendedor;
  }
}
