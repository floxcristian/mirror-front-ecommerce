import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AlertModule, BreadcrumbModule, CardModule, ModalModule } from './components';
import { DataFilterPipe } from './components/data-table/data-filter.pipe';
import { TodoListRemoveDirective } from './components/todo/todo-list-remove.directive';
import { TodoCardCompleteDirective } from './components/todo/todo-card-complete.directive';
import { PERFECT_SCROLLBAR_CONFIG, PerfectScrollbarConfigInterface, PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { ClickOutsideModule } from 'ng-click-outside';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { SpinnerComponent } from './components/spinner/spinner.component';
import { ApexChartComponent } from './components/chart/apex-chart/apex-chart.component';
import {ApexChartService} from './components/chart/apex-chart/apex-chart.service';
import { ToastComponent } from './components/toast/toast.component';
import {ToastService} from './components/toast/toast.service';
import { GalleryComponent } from './components/gallery/gallery.component';
import {LightboxModule} from 'ngx-lightbox';
import { MonedaPipe } from './pipes/moneda/moneda.pipe';
import { PasosCatalogoComponent } from './components/pasos-catalogo/pasos-catalogo.component';
import { IconSvgComponent } from './components/icon-svg/icon-svg.component';
import { CarruselProductosComponent } from './components/carrusel-productos/carrusel-productos.component';
import { BotonesNavegacionComponent } from './components/botones-navegacion/botones-navegacion.component';
import { CarouselModule } from 'ngx-owl-carousel-o';
import { RouterModule } from '@angular/router';
import { ModalEstadisticasUsuarioComponent } from './components/modals/modal-estadisticas-usuario/modal-estadisticas-usuario.component';
import { DatePickerComponent } from './components/datepicker/datepicker.component';
import { HttpClientModule } from '@angular/common/http';
import { TablaVentaDiariaComponent } from './components/tabla-ventadiaria/tabla-ventadiaria.component';
import { ToastrModule, ToastrService } from 'ngx-toastr';
import { LoadingComponent } from './components/loading/loading.component';
import { Ng2Rut } from 'ng2-rut';
import { FiltroPipe } from './pipes/filtro.pipe';
import { CrearSkuDesconectadoComponent } from './components/modals/crear-sku-desconectado/crear-sku-desconectado.component';
import { DetalleVendedorComponent } from './components/modals/detalle-vendedor/detalle-vendedor.component';
import { MasivaSkuDesconectadoComponent } from './components/modals/masiva-sku-desconectado/masiva-sku-desconectado.component';
import { ModificarSkuDesconectadoComponent } from './components/modals/modificar-sku-desconectado/modificar-sku-desconectado.component';
import { ReservasSkuDesconectadoComponent } from './components/modals/reservas-sku-desconectado/reservas-sku-desconectado.component';
import { VentasSkuDesconectadoComponent } from './components/modals/ventas-sku-desconectado/ventas-sku-desconectado.component';
import { NgxSpinnersModule } from 'ngx-spinners';
/*import 'hammerjs';
import 'mousetrap';
import { GalleryModule } from '@ks89/angular-modal-gallery';*/

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true
};

@NgModule({
  imports: [
    RouterModule,
    CarouselModule,
    CommonModule,
    PerfectScrollbarModule,
    FormsModule,
    ReactiveFormsModule,
    AlertModule,
    CardModule,
    BreadcrumbModule,
    ModalModule,
    ClickOutsideModule,
    LightboxModule,
    CarouselModule,
    NgbModule,
    HttpClientModule,
    ToastrModule,
    Ng2Rut,
    NgxSpinnersModule
   
  ],
  exports: [
    CommonModule,
    PerfectScrollbarModule,
    FormsModule,
    ReactiveFormsModule,
    AlertModule,
    CardModule,
    BreadcrumbModule,
    ModalModule,
    DataFilterPipe,
    TodoListRemoveDirective,
    TodoCardCompleteDirective,
    ClickOutsideModule,
    SpinnerComponent,
    ApexChartComponent,
    GalleryComponent,
    ToastComponent,
    ModalEstadisticasUsuarioComponent,
    PasosCatalogoComponent,
    IconSvgComponent,
    CarruselProductosComponent,
    BotonesNavegacionComponent,
    MonedaPipe,
    DatePickerComponent,
    TablaVentaDiariaComponent,
    LoadingComponent,
    Ng2Rut,
    FiltroPipe,
    CrearSkuDesconectadoComponent,
    DetalleVendedorComponent,
    MasivaSkuDesconectadoComponent,
    ModificarSkuDesconectadoComponent,
    ReservasSkuDesconectadoComponent,
    VentasSkuDesconectadoComponent
  ],
  declarations: [
    DataFilterPipe,
    MonedaPipe,
    TodoListRemoveDirective,
    TodoCardCompleteDirective,
    SpinnerComponent,
    ApexChartComponent,
    ToastComponent,
    GalleryComponent,
    ModalEstadisticasUsuarioComponent,
    PasosCatalogoComponent,
    IconSvgComponent,
    CarruselProductosComponent,
    BotonesNavegacionComponent,
    DatePickerComponent,
    TablaVentaDiariaComponent,
    LoadingComponent,
    FiltroPipe,

    CrearSkuDesconectadoComponent,
    DetalleVendedorComponent,
    MasivaSkuDesconectadoComponent,
    ModificarSkuDesconectadoComponent,
    ReservasSkuDesconectadoComponent,
    VentasSkuDesconectadoComponent
  ],
  bootstrap:[DatePickerComponent],
  providers: [
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    },
    ApexChartService,
    ToastService,
    ToastrService,
    HttpClientModule
  ]
})
export class SharedModule { }
