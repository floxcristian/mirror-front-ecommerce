import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { ToastrService } from 'ngx-toastr';
import { Observable, of } from 'rxjs';
import { delay, map } from 'rxjs/operators';


export interface Person {
  id: string;
  isActive: boolean;
  age: number;
  name: string;
  gender: string;
  company: string;
  email: string;
  phone: string;
  disabled?: boolean;
}


@Injectable({
  providedIn: 'root'
})
export class CatalogoService {
  header = new HttpHeaders(
    {
      "Accept": 'application/json',
      'Content-Type': 'application/json',
      'response-Type': 'json'
    }

  );
  constructor(private httpClient: HttpClient, private toast: ToastrService) { }

  async obtenerCatalogos() {
    
    let url = `${environment.endPointDev}${environment.obtenerCatalogos}`;
    let consulta: any = await this.httpClient.get(url).toPromise();

    if (!consulta.error) {
      return consulta.data;
    }
  }


  async obtenerUenCategoriaProductos() {
    let consulta = null
    let url = `${environment.endPoint}${environment.buscarClacom}`;
    consulta = await this.httpClient.get(url).toPromise();
    if (consulta.error) {
      this.toast.error('No se logro obtener los clacom');
      return
    }
    return consulta.data;
  }

  async obtenerProductos(parametros) {

    let consulta = null
    let url = `${environment.endPoint}${environment.obtenerProductos}`;

    consulta = await this.httpClient.post(url, parametros, { headers: this.header }).toPromise();
    console.log('data cons', consulta);
    if (consulta.error) {
      this.toast.error('No se logro obtener los productos');
      return
    }
    return consulta.data;
  }

  async generarCatalogo(parametros) {
    console.log('para', parametros);
    let consulta = null
    let url = `${environment.endPointDev}${environment.generarCatalogo}`;


    consulta = await this.httpClient.post(url, parametros, { headers: this.header }).toPromise();

    if (consulta.error) {
      this.toast.error(consulta.message);
      return consulta.data.cuerpo
    }
    return consulta.data;
  }

 
  async uploadImage(tipo: string, extension: string, image: File) {

    const formData = new FormData();

    formData.append('avatar', image);
    formData.append('tipo', tipo);



    let consulta: any = await this.httpClient.post(`${environment.endPointDev}api/catalogo/subirImagen`, formData).toPromise();
    console.log('consulta', consulta);

    if (consulta.respuesta == 'no se logro subir la imagen') {
      this.toast.error(consulta.respuesta);
      return
    }

    return consulta.data

  }

  getEstadoArticulos(): Observable<any> {
    return this.httpClient.get(`${environment.urlCatalogo}/estadoarticulos`);
  }
}

