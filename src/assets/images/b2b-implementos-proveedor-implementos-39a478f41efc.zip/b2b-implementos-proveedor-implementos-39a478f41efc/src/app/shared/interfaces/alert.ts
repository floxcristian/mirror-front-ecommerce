export class Alert {
    message: string;
    debug: string;
  }