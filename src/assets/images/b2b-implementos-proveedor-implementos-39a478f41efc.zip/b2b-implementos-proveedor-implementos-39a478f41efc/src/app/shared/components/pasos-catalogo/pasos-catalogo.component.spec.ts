import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PasosCatalogoComponent } from './pasos-catalogo.component';

describe('PasosCatalogoComponent', () => {
  let component: PasosCatalogoComponent;
  let fixture: ComponentFixture<PasosCatalogoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PasosCatalogoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PasosCatalogoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
