export interface InfoAnalytics {
    totalUsuarios?:  string;
    totalSesiones?:  string;
    promedioRebote?: string;
    fecha?:          string;
    visitas?:        string;
    sesiones?:       string;
    rebote?:         string;
}