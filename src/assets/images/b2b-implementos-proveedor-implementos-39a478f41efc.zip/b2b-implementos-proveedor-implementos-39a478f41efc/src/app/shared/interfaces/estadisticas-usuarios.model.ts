export interface EstadisticasUsuarios {
    error: boolean;
    msg:   string;
    data:  DataEstadisticasUsuarios;
}

export interface DataEstadisticasUsuarios {
    total:       { [key: string]: number };
    dia:         { [key: string]: number };
    mes:         { [key: string]: number };
    mesAnterior: { [key: string]: number };
    detalleDia:  DetalleDia[];
}

export interface DetalleDia {
    rut:      string;
    nombre:   string;
    empresa:  string;
    telefono: string;
    tipo:     Tipo;
}

export enum Tipo {
    Compradorb2C = "compradorb2c",
}