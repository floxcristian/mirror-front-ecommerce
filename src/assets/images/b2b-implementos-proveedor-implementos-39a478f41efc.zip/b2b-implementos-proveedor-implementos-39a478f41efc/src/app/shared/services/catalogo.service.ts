import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../../environments/environment.prod';
import { Observable } from 'rxjs/Observable';

@Injectable({
  providedIn: 'root'
})
export class CatalogoService {
  headers = new HttpHeaders().set('Content-Type','application/json; charset=utf-8');
  constructor(private http:HttpClient) { }

  getEstadoArticulos(): Observable<any>{
    return this.http.get(`${environment.urlCatalogo}/estadoarticulos`);
  }

}
