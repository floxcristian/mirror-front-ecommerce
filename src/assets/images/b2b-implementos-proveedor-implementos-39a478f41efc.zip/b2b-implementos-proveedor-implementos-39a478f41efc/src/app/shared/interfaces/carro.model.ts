export interface Carro {
    busquedas:           number;
    creacion:            Date;
    despacho:            number;
    elementos:           number;
    elementosEliminados: number;
    eliminados:          number;
    id:                  string;
    modificacion:        Date;
    monto:               number;
    montoEliminado:      number;
    productos:           number;
    rut:                 string;
    sucursal:            string;
    tipoCliente:         string;
    tipoCarro:           string;
    OV?:                 string;
    usuario:             string;
    productosDetalle:    any[];
    hash?:               number;
    paso?:                number;

}
