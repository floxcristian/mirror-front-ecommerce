import { Component, OnInit, Input } from '@angular/core';
import { DetalleDia } from 'src/app/shared/interfaces/estadisticas-usuarios.model';


@Component({
  selector: 'app-modal-estadisticas-usuario',
  templateUrl: './modal-estadisticas-usuario.component.html',
  styleUrls: ['./modal-estadisticas-usuario.component.scss']
})
export class ModalEstadisticasUsuarioComponent implements OnInit {
  @Input()
  detalleDia:DetalleDia[]=[]

  constructor() { }

  ngOnInit(): void {

  }

}
