import { Component, OnInit, Input } from '@angular/core';
import { OwlOptions } from 'ngx-owl-carousel-o';

@Component({
  selector: 'app-carrusel-productos',
  templateUrl: './carrusel-productos.component.html',
  styleUrls: ['./carrusel-productos.component.scss']
})
export class CarruselProductosComponent implements OnInit {
  @Input()productos: Array<any>=[];
  customOptions: OwlOptions = {
    loop: true,
    mouseDrag: false,
    touchDrag: false,
    pullDrag: false,
    dots: false,
    autoplay: true,
    navSpeed: 700,
    navText: ['<', '>'],
    responsive: {
      0: {
        items: 1
      },
      400: {
        items: 2
      },
      740: {
        items: 6
      },
      940: {
        items: 6
      }
    },
    nav: false
  }
  constructor() { }

  ngOnInit(): void {
  }

}
