import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { environment } from '../../../environments/environment.prod';

@Injectable({
  providedIn: 'root'
})
export class SolicitudService {

  headers = new HttpHeaders().set('Content-Type','application/json; charset=utf-8');

  constructor(private http:HttpClient) { }

  getClientesSolicitud(){
    return this.http.get(`${environment.urlSolicitud}/solicitudesb2b`)
  }

  aprobarSolicitud(id:string){
    let params = new HttpParams()
    params = params.append("id", id)
    return this.http.get(`${environment.urlAprobacion}/apruebab2b`, { params: params })
  }

  rechazarSolicitud(id:string){
    let params = new HttpParams()
    params = params.append("id", id)
    return this.http.get(`${environment.urlAprobacion}/rechazab2b`, { params: params })
  }

  getEstadisticasSolicitudes() {
    return this.http.get(`${environment.urlSolicitud}/estadisticassolicitudes`)
  }

  getClientes(ruts:string) {
    let params = new HttpParams();
    params = params.append("ruts", ruts)
    return this.http.get(`${environment.urlAprobacion}/listar-clientes`,{ params: params })
  }

  crearCliente(cliente:any) {
    let params = new HttpParams();
    return this.http.post(`${environment.urlAprobacion}/nuevoml`,{ params: cliente })
  }
  




}