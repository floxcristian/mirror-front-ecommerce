import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { HttpClient, HttpParams } from '@angular/common/http';
import { LocalStorageService } from 'angular-2-local-storage';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment.prod';

@Injectable({
  providedIn: 'root'
})
export class AutenticacionService {

  private currentUserSubject: BehaviorSubject<any>;
  public currentUser: Observable<any>;

  constructor(private httpClient: HttpClient, private localS: LocalStorageService,private router: Router) {
    this.currentUserSubject = new BehaviorSubject<any>(JSON.parse(this.localS.get('currentUser')));
    this.currentUser = this.currentUserSubject.asObservable();
  }

  public get currentUserValue() {
    
    return this.currentUserSubject.value;
  }

  async login(usuario) {
    let user = {
      user: usuario.strUsuario,
      pss: 'auth-token'
    }
    let consulta = null;
    const url = `https://b2b-api.implementos.cl/api/movil/loginUsuario`;
    consulta = await this.httpClient.post<any>(url, usuario).toPromise();
 
    if (consulta.length > 0) {
      await this.localS.set('usuario', JSON.stringify(consulta[0]));
      await this.localS.set('currentUser', JSON.stringify(user));
      await this.localS.set('codPerfil',consulta[0].codPerfil);
      await this.localS.set('codUsuario',consulta[0].codUsuario)

     
      await this.currentUserSubject.next(user);
      return consulta[0];
    } 
  
  }

  getPermisos(cod_perfil){
    let params = new HttpParams().append("cod_perfil", cod_perfil)
    return this.httpClient.get(`${environment.urlSeguridad}/getMenus`, { params: params})

  }

  getPermisosByUser(cod_user){
    let params = new HttpParams().append("cod_usuario", cod_user)
    return this.httpClient.get(`${environment.urlSeguridad}/getMenusUser`, { params: params})
  }

  async logout() {
    // remove user from local storage and set current user to null
    await this.localS.remove('usuario');
    await this.localS.remove('currentUser');
    await this.localS.remove('codPerfil');
    await this.localS.remove('codUsuario');
    await this.currentUserSubject.next(null);
    this.router.navigate(['/autenticacion']);
  }
}