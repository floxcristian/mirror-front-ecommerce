export interface DataAnalytics {
    totales: Totales;
    detalle: { [key: string]: Detalle[] };
}

export interface Detalle {
    tipo:     Tipo;
    cantidad: number;
}



export enum Tipo {
    agregarProductoFicha = "AgregarProducto-Ficha",
    comprobanteDeCompra = "Comprobante de compra",
    fichaSKU = "Ficha SKU",
    metodoDePago = "Metodo de pago",
    metodoDeEnvió = "Método de envió",
    paginaInicio = "Pagina Inicio",
    resumenCarro = "Resumen carro",
    shopping = "Shopping",
}

export interface Totales {
    "AgregarProducto-Ficha": number;
    "Comprobante de compra": number;
    "Ficha SKU":             number;
    "Metodo de pago":        number;
    "Método de envió":       number;
    "Pagina Inicio":         number;
    "Resumen carro":         number;
    Shopping:                number;
}