export interface InfoCarros {
    error: boolean;
    msg:   string;
    data:  DataCarro;
}

export interface DataCarro {
    detalleMes:                  { [key: string]: DetalleMe };
    cantidad:                    number;
    registrados:                 number;
    invitados:                   number;
    anonimos:                    number;
    monto:                       number;
    montoRegistrados:            number;
    montoInvitados:              number;
    montoAnonimos:               number;
    cantidadArticulos:           number;
    cantidadElementos:           number;
    montoEliminados:             number;
    cantidadEliminados:          number;
    cantidadElementosEliminados: number;
    busquedadSinResultados:      number;
    dataBusquedas:               DataBusqueda[];
    carros:                      Carro[];
}

export interface Carro {
    id:                  string;
    creacion:            Date;
    modificacion:        Date;
    rut:                 string;
    tipoCliente:         TipoCliente;
    usuario:             string;
    productos:           number;
    productosDetalle:    any[]
    elementos:           number;
    despacho:            number;
    monto:               number;
    sucursal:            string;
    eliminados:          number;
    elementosEliminados: number;
    montoEliminado:      number;
    busquedas:           number;
    tipoCarro:           TipoCarro;
}

export enum TipoCarro {
    B2B = "B2B",
    B2C = "B2C",
}

export enum TipoCliente {
    Anonimo = "Anonimo",
    Invitado = "Invitado",
    Registrado = "Registrado",
}

export interface DataBusqueda {
    texto: string;
}
export interface DetalleMe {
    cantidad: number;
}
