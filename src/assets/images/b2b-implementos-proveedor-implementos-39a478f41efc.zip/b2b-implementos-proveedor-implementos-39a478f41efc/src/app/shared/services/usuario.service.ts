import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../environments/environment.prod';

@Injectable({
  providedIn: 'root'
})
export class UsuarioService {
  headers = new HttpHeaders().set('Content-Type','application/json; charset=utf-8');
  constructor(private http:HttpClient) { }

  getUsuarioByUser(usuario:string){
    let params = new HttpParams()
    params = params.append("usuario", usuario)
    return this.http.get(`${environment.urlCarro}/usuariocarro/`,{params:params})
  }

  EstadisticasUsuarios(fechas){
    return this.http.post(`${environment.urlSolicitud}/estadisticasusuarios`, fechas , {headers:this.headers})
  }
}
