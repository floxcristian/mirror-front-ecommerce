import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReservasSkuDesconectadoComponent } from './reservas-sku-desconectado.component';

describe('ReservasSkuDesconectadoComponent', () => {
  let component: ReservasSkuDesconectadoComponent;
  let fixture: ComponentFixture<ReservasSkuDesconectadoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReservasSkuDesconectadoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReservasSkuDesconectadoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
