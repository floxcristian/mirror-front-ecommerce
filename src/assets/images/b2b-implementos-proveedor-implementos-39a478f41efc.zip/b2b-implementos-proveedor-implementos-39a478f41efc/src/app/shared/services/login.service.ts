import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../../environments/environment.prod';
import { tap} from 'rxjs/operators'
import { Usuario } from '../models/usuario.model';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  headers = new HttpHeaders().set('Content-Type','application/json; charset=utf-8');
  usuario:Usuario;

  constructor(private http:HttpClient,private router:Router) { }

  
login(credenciales){
  return this.http.post(`${environment.urlLogin}/loginUsuario`, credenciales, {headers:this.headers})
    .pipe( 
      tap( (user:Usuario) => { 
      this.usuario = user[0]
      localStorage.setItem("usuario", JSON.stringify(this.usuario))
    }))    

}

getUsuario(){
  return JSON.parse(localStorage.getItem("usuario"))
}

logout(){
  localStorage.removeItem("usuario");
  localStorage.removeItem("token");
  this.router.navigate(['/login'])
}


}
