import { Injectable } from '@angular/core';


import { User } from '../models/user';
import { Router } from '@angular/router';


@Injectable({
  providedIn: 'root'
})

export class AuthService {
 /*  public authenticated: boolean;
  public user: User;

  constructor(
    private msalService: MsalService,
    private alertsService: AlertsService,
    private router:Router) {
      this.authenticated = this.msalService.getAccount() != null;
      this.getUser().then((user) => {this.user = user});
  }

  public async getUser(): Promise<User> {
    if (!this.authenticated) return null;
  
    let graphClient = Client.init({
      // Initialize the Graph client with an auth
      // provider that requests the token from the
      // auth service
      authProvider: async(done) => {
        let token = await this.getAccessToken()
          .catch((reason) => {
            done(reason, null);
          });
  
        if (token)
        {
          done(null, token);
        } else {
          done("Could not get an access token", null);
        }
      }
    });
  
    // Get the user from Graph (GET /me)
    let graphUser = await graphClient.api('/me').get();
  
    let user = new User();
    user.displayName = graphUser.displayName;
    // Prefer the mail property, but fall back to userPrincipalName
    user.email = graphUser.mail || graphUser.userPrincipalName;
  
    return user;
  }

  // Prompt the user to sign in and
  // grant consent to the requested permission scopes
  async signIn(): Promise<void> {
    let result = await this.msalService.loginPopup(OAuthSettings)
      .catch((reason) => {
      });

    if (result) {
      this.authenticated = true;
      this.user = await this.getUser();
      localStorage.setItem('user',JSON.stringify(this.user))
      console.log(this.user);
      this.router.navigate(['/funnel'])

    }
  }

  // Sign out
  signOut(): void {
    this.msalService.logout();
    this.user = null;
    this.authenticated = false;
    localStorage.removeItem('user')
    this.router.navigate(['/login'])
    
  }

  // Silently request an access token
  async getAccessToken(): Promise<string> {
    let result = await this.msalService.acquireTokenSilent(OAuthSettings)
      .catch((reason) => {
        this.alertsService.add('Get token failed', JSON.stringify(reason, null, 2));
      });

    if (result) {
      // Temporary to display token in an error box
      return result.accessToken;
    }
    return null;
  } */
}