import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VentasSkuDesconectadoComponent } from './ventas-sku-desconectado.component';

describe('VentasSkuDesconectadoComponent', () => {
  let component: VentasSkuDesconectadoComponent;
  let fixture: ComponentFixture<VentasSkuDesconectadoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VentasSkuDesconectadoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VentasSkuDesconectadoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
