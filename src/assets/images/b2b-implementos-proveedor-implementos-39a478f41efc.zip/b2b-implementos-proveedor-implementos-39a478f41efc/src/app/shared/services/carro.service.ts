import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders,HttpParams } from '@angular/common/http';
import { environment } from '../../../environments/environment.prod';
@Injectable({
  providedIn: 'root'
})
export class CarroService {

  headers = new HttpHeaders().set('Content-Type','application/json; charset=utf-8');
  estadisticas:any;
  infoVenta:any;

  constructor(private http:HttpClient) { }

  getCarros(fecha){
    return this.http.post(`${environment.urlCarro}/buscarcarrosfecha`, fecha, { headers: this.headers })
  }
  
  filtrarFechas(fecha){
    return this.http.post(`${environment.urlCarro}/buscarcarrosfecha`, fecha, { headers: this.headers } )
  }
  
  estadisticasFecha(fecha?){
    return this.http.post(`${environment.urlCarro}/estadisticas`, fecha , {headers:this.headers})
  }
  
  getAnalytics(fechas){
    let params = new HttpParams().append("inicio", fechas.inicio).append("termino", fechas.termino)
    return this.http.get(`${environment.urlCarro}/analytics`, { params: params})
  }
  
  getCompraOv(ov:string){
    let params = new HttpParams().append("ov", ov)
    return this.http.get(`${environment.urlCarro}/detallepago`, {params: params})
  }
  
  getMlToken() {
    let params = new HttpParams();
    return this.http.get(`${environment.urlCarro}/mercado-libre/auth`, { params: params, headers: this.headers });
  }

  // getPaidOrders(token, page=1, pageSize=10) {
  //   let params = new HttpParams()
  //       .append("token", String(token))
  //       .append("page", String(page))
  //       .append("pageSize", String(pageSize));
  //   return this.http.get(`${environment.urlCarro}/mercado-libre/paid-orders`, { params: params, headers: this.headers })
  // }


  getRecentOrders(page=1, pageSize=30, tipo_orden, search_text="") {
    let params = new HttpParams()
        .append("page", String(page))
        .append("q", String(tipo_orden))
        .append("pageSize", String(pageSize))
        .append("searchText", search_text);

    return this.http.get(`${environment.urlCarro}/mercado-libre/recent-orders`, { params: params, headers: this.headers })
  }

  getProducts(skus) {
    let params = new HttpParams()
      .append("skus", skus);

    return this.http.get(`${environment.urlCarro}/mercado-libre/obtener-productos`, { params: params, headers: this.headers })
  }

  getLabel(shipping_id) {
    let params = new HttpParams()
      .append("shipping_id", shipping_id);
    return this.http.get(`${environment.urlCarro}/mercado-libre/labels`, { params: params, headers: this.headers })
  }
  
  crearOV(order_id, tipo_documento) {
    let params = new HttpParams()
      .append("order_id", order_id)
      .append("tipo_documento", tipo_documento);
    return this.http.get(`${environment.urlCarro}/mercado-libre/crear-ax-ov`, { params: params, headers: this.headers })
  }

  



}