export class Clacom {
    uens?:Array<ObjetoBase> =[]
    categorias?:Array<ObjetoBase> =[]
    lineas?:Array<ObjetoBase> =[]
}
interface ObjetoBase{
    codigoPadre?: number,
    codigo: number,
    nombre: string
}