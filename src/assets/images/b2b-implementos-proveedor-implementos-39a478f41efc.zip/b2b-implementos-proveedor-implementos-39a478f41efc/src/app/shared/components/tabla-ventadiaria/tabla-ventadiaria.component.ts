import { Component, OnInit, Input} from '@angular/core';
import { Carro } from '../../models/carro.model';
import { UsuarioService } from '../../services/usuario.service';
import {tap} from 'rxjs/operators'
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
//import { NgbdModal3Content } from '../ngb-modal-carro/ngb-modal-carro.component';



@Component({
  selector: 'app-tabla-ventadiaria',
  templateUrl: './tabla-ventadiaria.component.html',
  styleUrls: ['./tabla-ventadiaria.component.scss']
})
export class TablaVentaDiariaComponent implements OnInit {

  mostrarTabla = false;
  archivo:string 
  anchoScreen = screen.width;
  altoScreen = screen.availHeight;
  @Input()
  carros: Carro[] = [];
  @Input() 
  tipo: string = "";
  @Input()
  usuario:any = {}
  modalToggle:boolean = false;
  arregloB2B:any[] = []
  arregloB2C:any[] = []
  path:any
  order:any
  iterable:Carro[]
  totalItems: number;
  page: number = 1;
  pageSize:number = 10;

  


  constructor(private usuarioService:UsuarioService, private modalService:NgbModal) { 
    this.archivo = "VentaDia_" + new Date().toISOString() + ".xlsx"
    
  }
  
   open(user:string){
    console.log(user);
/*     this.usuarioService.getUsuarioByUser(user).pipe(
      tap((data:any) => { 
        this.usuario = data.data
        console.log(this.usuario);
        let modalRef = this.modalService.open(NgbdModal3Content)
        modalRef.componentInstance.usuario = this.usuario
        })
    ).subscribe() */



  } 
   ngOnInit():void{
    for (let i = 0; i < this.carros.length; i++) {
      this.carros[i] = {...this.carros[i], hash:i+1}
    }
     for(let i in this.carros){
       switch(this.carros[i].tipoCarro){
         case "B2B": this.arregloB2B.push(this.carros[i])
         break;
         case "B2C": this.arregloB2C.push(this.carros[i])
         break;
       }
     }
   }
}
