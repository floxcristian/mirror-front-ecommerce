export interface InfoOvCliente {
    error: boolean;
    msg:   string;
    data:  DataOV;
}

export interface DataOV {
    rut:                string;
    nombre:             string;
    telefono:           string;
    direccion:          string;
    observacion:        string;
    formaPago:          string;
    numeroTarjeta:      string;
    codigoAutorizacion: string;
    ordenCompra:        string;
    monto:              number;
    cuotas:             string;
}