import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { ArticulosService } from 'src/app/shared/services/articulos/articulos.service';

@Component({
  selector: 'app-reservas-sku-desconectado',
  templateUrl: './reservas-sku-desconectado.component.html',
  styleUrls: ['./reservas-sku-desconectado.component.scss']
})

export class ReservasSkuDesconectadoComponent implements OnInit {
@Input()reservados:any;
@Input()modalReservasRef:BsModalRef;
@Output() public actualizar = new EventEmitter<any>();
  constructor(private articulosv2: ArticulosService ) { }  
  ngOnInit(): void {
  }
  async actualizarDocumentoReserva(objecto) {
    //let {nombre,edad,correo,direccion}=this.formCrear.value;
    console.log('entre al actualizarDocumentoReserva', objecto);
    let respuesta = await this.articulosv2.ActualizadoDocumentoDesconectado(objecto.documento);

    if (!respuesta.error){
      this.actualizar.emit(true);  
      this.modalReservasRef.hide();    
    }
    console.log('respuesta',respuesta)
  }

}
