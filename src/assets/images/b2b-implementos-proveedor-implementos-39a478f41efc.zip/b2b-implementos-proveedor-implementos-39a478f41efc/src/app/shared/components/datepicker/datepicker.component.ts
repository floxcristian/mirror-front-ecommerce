import {Component, Input} from '@angular/core';
import {NgbDateStruct} from '@ng-bootstrap/ng-bootstrap';


@Component({
  selector: 'app-datepicker',
  templateUrl: './datepicker.component.html'
})
export class DatePickerComponent {
  
  model: Date;

  @Input()
  placeholder:string


  
}