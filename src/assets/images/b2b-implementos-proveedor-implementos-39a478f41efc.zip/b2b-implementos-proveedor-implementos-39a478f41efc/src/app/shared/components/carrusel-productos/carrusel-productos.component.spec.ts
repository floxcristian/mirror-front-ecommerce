import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CarruselProductosComponent } from './carrusel-productos.component';

describe('CarruselProductosComponent', () => {
  let component: CarruselProductosComponent;
  let fixture: ComponentFixture<CarruselProductosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CarruselProductosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CarruselProductosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
