export class User {
    displayName: string;
    email: string;
    avatar: string;
  }