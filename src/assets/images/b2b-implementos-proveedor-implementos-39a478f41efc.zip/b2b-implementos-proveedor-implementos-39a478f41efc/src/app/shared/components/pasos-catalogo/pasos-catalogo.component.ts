import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-pasos-catalogo',
  templateUrl: './pasos-catalogo.component.html',
  styleUrls: ['./pasos-catalogo.component.scss']
})
export class PasosCatalogoComponent implements OnInit {
  @Input() step = 1;
  innerWidth : number
  constructor() {
    this.innerWidth = window.innerWidth
   }
  
  ngOnInit() {
  }
  onResize(event) {
    this.innerWidth = event.target.innerWidth;
}
}
