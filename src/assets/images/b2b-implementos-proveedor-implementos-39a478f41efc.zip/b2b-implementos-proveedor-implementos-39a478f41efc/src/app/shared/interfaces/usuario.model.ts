export interface Usuario {
    codUsuario:     number;
    codEmpleado:    number;
    codSucursal:    string;
    rut:            string;
    codBodega:      string;
    codPerfil:      number;
    nombre:         string;
    nombreSucursal: string;
    codCliente:     number;
}