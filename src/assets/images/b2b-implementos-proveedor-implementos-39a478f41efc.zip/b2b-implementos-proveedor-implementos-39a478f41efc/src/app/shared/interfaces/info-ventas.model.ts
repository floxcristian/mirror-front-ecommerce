export interface InfoVenta {
    error: boolean;
    msg:   string;
    data:  DataInfoVenta;
}

export class DataInfoVenta {
    detalleMes?:        DetalleMes;
    detalleMesAnterior?:DetalleMes
    cantidad?:          number;
    cantidadB2B?:       number;
    cantidadB2C?:       number;
    monto?:             number;
    montoB2B?:          number;
    montoB2C?:          number;
    cantidadArticulos?: number;
    carros?:            Carro[];


}



export interface Carro {
    id:           string;
    creacion:     Date;
    modificacion: Date;
    rut:          string;
    usuario:      string;
    productos:    number;
    despacho:     number;
    monto:        number;
    sucursal:     string;
    eliminados:   number;
    busquedas:    number;
    tipoCarro:    TipoCarro;
    OV:string;
    productosDetalle:    any[];
}

export enum TipoCarro {
    B2C = "B2C",
}

export interface DetalleMes {
    sumaMes:        number ;
    sumaB2B:        number;
    sumaB2C:        number;
    cantidadVentas: number;
    cantidadB2B:    number;
    cantidadB2C:    number;
    detalleDias:    { [key: string]: DetalleDia };
}

export interface DetalleDia {
    total: number;
}
