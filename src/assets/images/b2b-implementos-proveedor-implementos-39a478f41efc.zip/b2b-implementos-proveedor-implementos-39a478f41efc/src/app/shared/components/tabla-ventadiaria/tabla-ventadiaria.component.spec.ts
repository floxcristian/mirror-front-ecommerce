import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TablaVentadiariaComponent } from './tabla-ventadiaria.component';

describe('TablaVentadiariaComponent', () => {
  let component: TablaVentadiariaComponent;
  let fixture: ComponentFixture<TablaVentadiariaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TablaVentadiariaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TablaVentadiariaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
