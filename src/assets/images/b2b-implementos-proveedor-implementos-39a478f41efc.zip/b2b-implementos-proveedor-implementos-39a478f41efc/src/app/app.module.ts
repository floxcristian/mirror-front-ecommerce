import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { SharedModule } from './shared/shared.module';

import { AppComponent } from './app.component';
import { AdminComponent } from './theme/layout/admin/admin.component';
import { AuthComponent } from './theme/layout/auth/auth.component';
import { NavigationComponent } from './theme/layout/admin/navigation/navigation.component';
import { NavContentComponent } from './theme/layout/admin/navigation/nav-content/nav-content.component';
import { NavGroupComponent } from './theme/layout/admin/navigation/nav-content/nav-group/nav-group.component';
import { NavCollapseComponent } from './theme/layout/admin/navigation/nav-content/nav-collapse/nav-collapse.component';
import { NavItemComponent } from './theme/layout/admin/navigation/nav-content/nav-item/nav-item.component';
import { NavBarComponent } from './theme/layout/admin/nav-bar/nav-bar.component';
import { NavLeftComponent } from './theme/layout/admin/nav-bar/nav-left/nav-left.component';
import { NavSearchComponent } from './theme/layout/admin/nav-bar/nav-left/nav-search/nav-search.component';
import { NavRightComponent } from './theme/layout/admin/nav-bar/nav-right/nav-right.component';
import { ConfigurationComponent } from './theme/layout/admin/configuration/configuration.component';

import { ToggleFullScreenDirective } from './shared/full-screen/toggle-full-screen';

/* Menu Items */
import { NavigationItem } from './theme/layout/admin/navigation/navigation';
import { NgbButtonsModule, NgbDropdownModule, NgbTabsetModule, NgbTooltipModule, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientModule ,HTTP_INTERCEPTORS } from '@angular/common/http';
import { BasicAuthInterceptor, } from './basic-auth.interceptor';
import { LOCALE_ID } from '@angular/core';
import { registerLocaleData, CommonModule } from '@angular/common';
import localeEsCl from '@angular/common/locales/es-CL';

import { PageResumenComponent } from './modules/resumen/pages/page-resumen/page-resumen.component';
import { ResumenModule } from './modules/resumen/resumen.module';
import { PageFunnelComponent } from './modules/funnel/pages/page-funnel/page-funnel.component';
import 'hammerjs';

// Import FusionCharts library and chart modules

import { FunnelModule } from './modules/funnel/funnel.module';

// Pass the fusioncharts library and chart modules
import { ChartModule } from '@progress/kendo-angular-charts';

// Imports the Sparkline module
import { SparklineModule } from '@progress/kendo-angular-charts';

import { ModalModule } from 'ngx-bootstrap/modal';
import { PageNotFoundComponent } from './pages/page-not-found/page-not-found.component';
import { ToastrModule } from 'ngx-toastr';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { LocalStorageModule } from 'angular-2-local-storage';
import { AutenticacionModule } from './modules/autenticacion/autenticacion.module';
import { ArticulosModule } from './modules/articulos/articulos.module';
import { NgxSpinnersModule } from 'ngx-spinners';




registerLocaleData(localeEsCl);
@NgModule({
  declarations: [
    AppComponent,
    AdminComponent,
    AuthComponent,
    NavigationComponent,
    NavContentComponent,
    NavGroupComponent,
    NavCollapseComponent,
    NavItemComponent,
    NavBarComponent,
    NavLeftComponent,
    NavSearchComponent,
    NavRightComponent,
    ConfigurationComponent,
    ToggleFullScreenDirective,
    PageNotFoundComponent,
  ],
  imports: [
    CommonModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    SharedModule,
    NgbDropdownModule,
    NgbTooltipModule,
    NgbButtonsModule,
    NgbTabsetModule,
    ModalModule.forRoot(),
    LocalStorageModule.forRoot({
      prefix: 'AdminImplementos',
      storageType: 'localStorage'
    }),
    ToastrModule.forRoot(),
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    AutenticacionModule,
    ArticulosModule,
    NgxSpinnersModule
  ],
  exports:[
    AdminComponent
  ],
  providers: [NavigationItem,HttpClientModule,{
    provide: HTTP_INTERCEPTORS,
    useClass: BasicAuthInterceptor,
    multi: true

  },
  
  ResumenModule,
  NgbModule,
  FunnelModule,
  ChartModule,
  SparklineModule,
  {
    provide: LOCALE_ID,
    useValue: "es-CL"
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
