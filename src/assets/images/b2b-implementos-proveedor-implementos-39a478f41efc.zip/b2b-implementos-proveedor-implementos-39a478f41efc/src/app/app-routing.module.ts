import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminComponent } from './theme/layout/admin/admin.component';
import { AuthComponent } from './theme/layout/auth/auth.component';
import { AutenticacionGuard } from './shared/guard/autenticacion.guard';
import { PageNotFoundComponent } from './pages/page-not-found/page-not-found.component';
import { ResumenRoutingModule } from './modules/resumen/resumen-routing.module';
import { AutenticacionRoutingModule } from './modules/autenticacion/autenticacion-routing.module';

const routes: Routes = [
  
  {
    path: '',
    redirectTo: 'resumen',
    pathMatch: 'full'
  },

 /*  {
    path: '',
    loadChildren: () => import('./modules/autenticacion/autenticacion.module').then(module => module.AutenticacionModule)

  }, */
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes),
    AutenticacionRoutingModule,
    ResumenRoutingModule,
    
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
