import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {NextConfig} from '../../../../app-config';
import { AutenticacionService } from 'src/app/shared/services/autenticacionService/autenticacion.service';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.scss']
})
export class NavigationComponent implements OnInit {
  public windowWidth: number;
  public nextConfig: any;
  @Output() onNavMobCollapse = new EventEmitter();

  constructor(private autenticacionService:AutenticacionService) {
    this.nextConfig = NextConfig.config;
    this.windowWidth = window.innerWidth;
  }

  ngOnInit() {

   }

  navMobCollapse() {
    if (this.windowWidth < 450) {
      this.onNavMobCollapse.emit();
    }
  }
}
