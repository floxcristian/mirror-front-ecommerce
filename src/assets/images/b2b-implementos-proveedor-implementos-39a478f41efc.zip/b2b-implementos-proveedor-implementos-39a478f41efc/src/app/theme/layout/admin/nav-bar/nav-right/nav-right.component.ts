import {Component, OnInit} from '@angular/core';
import {NgbDropdownConfig} from '@ng-bootstrap/ng-bootstrap';
import { AutenticacionService } from 'src/app/shared/services/autenticacionService/autenticacion.service';

@Component({
  selector: 'app-nav-right',
  templateUrl: './nav-right.component.html',
  styleUrls: ['./nav-right.component.scss'],
  providers: [NgbDropdownConfig]
})
export class NavRightComponent implements OnInit {
  user:any

  constructor(private autenticacionService : AutenticacionService) { }

   ngOnInit() { 
    const currentUser = this.autenticacionService.currentUserValue;
    this.user = currentUser.user;


  }

  cerrarSesion(){
    this.autenticacionService.logout();
    console.log('cerrar');
  }
}
