import {Injectable} from '@angular/core';
import { AutenticacionService } from 'src/app/shared/services/autenticacionService/autenticacion.service';

export interface NavigationItem {
  id: string;
  title: string;
  type: 'item' | 'collapse' | 'group';
  translate?: string;
  icon?: string;
  hidden?: boolean;
  url?: string;
  classes?: string;
  exactMatch?: boolean;
  external?: boolean;
  target?: boolean;
  breadcrumbs?: boolean;
  function?: any;
  badge?: {
    title?: string;
    type?: string;
  };
  children?: Navigation[];
}

export interface Navigation extends NavigationItem {
  children?: NavigationItem[];
}

const NavigationItems = [
  {
    id: 'Menu',
    title: 'Menu',
    type: 'group',
    icon: 'feather icon-monitor',
    children: [
      {
        id: 'resumen',
        title: 'Resumen',
        type: 'item',
        url: '/resumen',
        icon: 'feather icon-home',
        classes: 'nav-item',
        permisos:0
      },
      /* {
        id: 'solicitudesB2B',
        title: 'Solicitudes B2B',
        type: 'item',
        url: '/admin/solicitudes',
        icon: 'far fa-clipboard',
        classes: 'nav-item'
      },
    
      {
        id: 'carrosPerdidos',
        title: 'Carros Perdidos',
        type: 'item',
        url: '/admin/carros-perdidos',
        icon: 'fas fa-shopping-cart',
        classes: 'nav-item'
      },
      {
        id: 'usuarios',
        title: 'Usuarios nuevos',
        type: 'item',
        url: '/admin/usuarios',
        icon: 'far fa-user',
        classes: 'nav-item'
      },
      
      {
        id: 'busquedaOv',
        title: 'Busqueda OV',
        type: 'item',
        url: '/admin/ordenes-ventas',
        icon: 'fas fa-search',
        classes: 'nav-item'
      },
      {
        id: 'funnel',
        title: 'Funnel',
        type: 'item',
        url: '/admin/funnel',
        icon: 'fas fa-chart-pie',
        classes: 'nav-item'
      },

      {
        id: 'mercadoLibre',
        title: 'Mercado Libre',
        type: 'item',
        url: '/admin/mercado-libre',
        icon: 'fas fa-store',
        classes: 'nav-item'
      },
      {
        id: 'estadoArticulo',
        title: 'Estado Articulos',
        type: 'item',
        url: '/admin/articulos',
        icon: 'far fa-list-alt',
        classes: 'nav-item'
      }, */
      {
        id: 'articulos',
        title: 'Articulos',
        type: 'collapse',
        icon: 'fa fa-book-open',
        children: [
          {
            id: 'artDesconectados',
            title: 'Articulos Desconectados',
            type: 'item',
            url: '/articulos/articulos-desconectados',
            target: false
          },
          
        ]
      }
    ]
  }
];

@Injectable()
export class NavigationItem {
  menuDinamico:any
  constructor()
  {}
  public get() {

    return NavigationItems;
  }

  
}
