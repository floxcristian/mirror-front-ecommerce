// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: true,
  urlCarro: "https://b2b-api.implementos.cl/api/carro",
  urlLogin: "https://b2b-api.implementos.cl/api/movil",
  urlSolicitud: "https://b2b-api.impelementos.cl/api/cliente",
  urlAprobacion: "https://b2b-api.impelementos.cl/api/cliente",
  urlCatalogo: "https://b2b-api.implementos.cl/api/catalogo",
  //urlSeguridad:"http://localhost:9000/api/seguridad",
  urlSeguridad:"https://b2b-api.implementos.cl/api/seguridad",

  //catalogo
  endPoint: 'https://b2b-api.implementos.cl/',
  endPointDev:'https://dev-api.implementos.cl/',
  endPointLocal :'http://localhost:9002/',
  buscarClacom: 'api/catalogo/buscarclacom',
  obtenerProductos: 'api/catalogo/busquedaProductosCatalogos',
  generarCatalogo:'api/catalogo/generarCatalogo',
  obtenerCatalogos:'api/catalogo/obtenerCatalogos',
  template: [
    { titulo: 'Un producto', foto: '../../../../../assets/img/unproducto.png', control: 'template', value: 'unproducto',atributos:13 },
    { titulo: 'Tabla de producto', foto: '../../../../../assets/img/tablaproductos.png', control: 'template', value: 'tablaproductos',atributos:6 },
    { titulo: 'Productos Vertical', foto: '../../../../../assets/img/vertical.png', control: 'template', value: 'vertical',atributos:5 },
    { titulo: 'Productos Horizontales', foto: '../../../../../assets/img/horizontal.png', control: 'template', value: 'horizontal',atributos:5 }
  ],
  selectProductos: [
    { nombre: 'UEN' },
    { nombre: 'Categoria' },
    { nombre: 'Linea' },
  ],
  atributos: [
    {
      id: 'Nombre',
      atrib: 'atributo'
    },
    {
      id: 'Descripcion',
      atrib: 'atributo'
    },
    {
      id: 'Precio',
      atrib: 'atributo'
    }
  ]
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
